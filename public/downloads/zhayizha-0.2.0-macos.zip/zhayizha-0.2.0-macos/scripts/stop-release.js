import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {execFileSync} from 'node:child_process';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),file=path.join(root,'data/server.pid');
if(!fs.existsSync(file)){console.log('当前目录没有运行记录 / No running service in this folder.');process.exit(0);}
const pid=Number(fs.readFileSync(file,'utf8'));if(!Number.isInteger(pid)||pid<2)throw new Error('Invalid PID');
try{
 const command=execFileSync('ps',['-p',String(pid),'-o','command='],{encoding:'utf8'});
 const cwd=execFileSync('lsof',['-a','-p',String(pid),'-d','cwd','-Fn'],{encoding:'utf8'}).split('\n').find(l=>l.startsWith('n'))?.slice(1);
 if(!command.includes('src/server.js')||fs.realpathSync(cwd||'/')!==fs.realpathSync(root))throw new Error('Process belongs to a different folder. Not stopped.');
 process.kill(pid,'SIGTERM');console.log('已请求停止 / Stop requested.');
}catch(e){console.error('未停止其他进程，请检查运行目录 / No unrelated process was stopped.',e.message);process.exitCode=1;}
