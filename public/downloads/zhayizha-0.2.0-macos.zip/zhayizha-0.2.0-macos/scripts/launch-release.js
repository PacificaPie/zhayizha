import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn, execFileSync } from 'node:child_process';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const port=Number(process.env.PORT||4317);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('Invalid PORT');
const url=`http://localhost:${port}`;
async function ready(){try{const r=await fetch(url+'/api/state',{signal:AbortSignal.timeout(1500)});const s=await r.json();return r.ok&&s.features?.localOnly===true&&Array.isArray(s.notes)&&Array.isArray(s.jobs);}catch{return false;}}
function belongsToThisFolder(){
 try{
  const pid=Number(fs.readFileSync(path.join(root,'data/server.pid'),'utf8'));
  if(!Number.isInteger(pid)||pid<2)return false;
  const command=execFileSync('ps',['-p',String(pid),'-o','command='],{encoding:'utf8'});
  const cwd=execFileSync('lsof',['-a','-p',String(pid),'-d','cwd','-Fn'],{encoding:'utf8'}).split('\n').find(l=>l.startsWith('n'))?.slice(1);
  const listener=execFileSync('lsof',['-nP','-a','-p',String(pid),'-iTCP:'+port,'-sTCP:LISTEN','-t'],{encoding:'utf8'}).trim();
  return listener===String(pid)&&command.includes('src/server.js')&&fs.realpathSync(cwd||'/')===fs.realpathSync(root);
 }catch{return false;}
}
const alreadyReady=await ready();
if(alreadyReady&&!belongsToThisFolder()){
 console.error('此端口已有其他目录的扎一扎服务。请先停止原服务，或在 .env 选择不同 PORT。 / Another copy is running on this port. Stop that copy or choose a different PORT in .env.');process.exit(1);
}
if(!alreadyReady){
 fs.mkdirSync(path.join(root,'data'),{recursive:true,mode:0o700});
 const log=fs.openSync(path.join(root,'data/server.log'),'a',0o600);
 const child=spawn(process.execPath,['--env-file-if-exists=.env','src/server.js'],{cwd:root,detached:true,stdio:['ignore',log,log]});child.unref();fs.closeSync(log);
 let ok=false;for(let i=0;i<50;i++){if(await ready()&&belongsToThisFolder()){ok=true;break;}await new Promise(r=>setTimeout(r,200));}
 if(!ok){console.error('未能启动，请查看 data/server.log / Start failed; check data/server.log.');process.exit(1);}
}
if(process.platform==='darwin'&&process.env.ZHAYIZHA_NO_OPEN!=='1')execFileSync('open',[url]);
console.log(`扎一扎 / Pin a Wish: ${url}\n服务在后台运行。关闭请双击 Stop.command。 / Running in the background. Use Stop.command to stop.`);
