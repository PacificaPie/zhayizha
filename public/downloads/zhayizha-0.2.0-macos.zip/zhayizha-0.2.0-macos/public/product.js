const $ = s => document.querySelector(s);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const link = value => { try { const u = new URL(value); return u.protocol === 'https:' ? u.href : ''; } catch { return ''; } };
let ctx, currentPlace, currentNote, candidate, sequence = 0, guideStep = 0, guideOperation = null, prompted = false;
const boardOperations = new Set();
function confirmEnabled() { $('#review-confirm').disabled = !candidate || !$('#review-ack').checked; }
function candidatesHtml(list) {
  candidate = null; $('#review-ack').checked = false; confirmEnabled();
  $('#review-candidates').innerHTML = list.length ? list.map((c,i)=>`<article class="candidate"><strong>${esc(c.displayedName)}</strong><p>${esc(c.address || '未读取到地址，请在地图详情核对地址与分店。')}</p>${link(c.mapUrl)?`<a href="${esc(link(c.mapUrl))}" target="_blank" rel="noopener noreferrer">打开 Google Maps ↗</a>`:''}<button class="button secondary" data-choose-candidate="${i}">选择这个候选</button></article>`).join('') : '<p class="muted">没有候选。请在浏览器打开具体地点后，再读取位置。</p>';
  $('#review-candidates').querySelectorAll('[data-choose-candidate]').forEach(b => b.addEventListener('click',()=>{
    candidate = list[Number(b.dataset.chooseCandidate)]; $('#review-ack').checked=false; confirmEnabled();
    $('#review-candidates').querySelectorAll('article').forEach(el=>el.classList.remove('chosen'));
    b.closest('article').classList.add('chosen');
    $('#review-candidates').querySelectorAll('button').forEach(el=>el.textContent='选择这个候选'); b.textContent='已选择';
  }));
}
async function openReview(placeId,noteId) {
  const token=++sequence, state=ctx.getState(); currentPlace=placeId; currentNote=noteId;
  const p=state.places.find(p=>p.id===placeId); if(!p) return;
  $('#review-title').textContent=p.name; $('#review-url').value=p.map_url||'';
  $('#review-source').innerHTML='<p>正在读取原文…</p>'; candidatesHtml([]);
  $('#review-api-search').hidden=!state.features.places;
  $('#defer-controls').hidden=state.jobs.some(j=>(j.placeIds||[j.place_id]).includes(p.id));
  $('#review-dialog').showModal();
  try {
    const n=await ctx.api(`/api/notes/${encodeURIComponent(noteId)}/evidence`); if(token!==sequence||!$('#review-dialog').open)return;
    $('#review-source').innerHTML=`<h4>${esc(n.title)}</h4><div class="source-clue"><strong>地点线索</strong><p>${esc([p.name,p.city,p.address].filter(Boolean).join(' · '))}</p><blockquote>${esc(p.evidence||'未附原文依据，请查看笔记。')}</blockquote></div>${p.review?`<p class="note-error">上次暂存：${esc(p.review.reason)}</p>`:''}<pre>${esc(n.body||'这篇笔记没有正文，可对照下方图片。')}</pre>${n.images.length?`<div class="source-images">${n.images.map((url,i)=>`<figure><a href="${esc(url)}" target="_blank" rel="noopener"><img src="${esc(url)}" alt="原笔记图片 ${i+1}" loading="lazy"></a><figcaption>图片 ${i+1} · 点击放大</figcaption></figure>`).join('')}</div>`:''}${link(n.url)?`<a href="${esc(link(n.url))}" target="_blank" rel="noopener noreferrer">打开原笔记 ↗</a>`:''}`;
    $('#review-source').querySelectorAll('img').forEach(img=>img.addEventListener('error',()=>{img.closest('figure').innerHTML='<p class="muted">图片暂时无法加载，请打开原笔记核对。</p>';},{once:true}));
  } catch(e) { if(token===sequence) $('#review-source').textContent=e.message; }
}
function showStep() {
  document.querySelectorAll('[data-guide-step]').forEach(el=>el.hidden=Number(el.dataset.guideStep)!==guideStep);
  $('#guide-steps').querySelectorAll('li').forEach((el,i)=>{el.classList.toggle('active',i===guideStep);if(i===guideStep)el.setAttribute('aria-current','step');else el.removeAttribute('aria-current');});
  $('#guide-back').hidden=guideStep===0; $('#guide-next').hidden=guideStep===3;
  $('#guide-start').hidden=guideStep!==3; $('#guide-finish').hidden=true;
  $('#guide-next').disabled=guideStep===1&&['xhs','google'].some(k=>ctx.getState().connections[k]!=='connected');
}
function openGuide() {
  const state=ctx.getState(),f=$('#guide-form'); f.reset(); guideStep=0; guideOperation=null;
  for(const key of ['city','targetList','boardName','boardUrl'])f.elements[key].value=state.settings[key]||'';
  f.elements.extract.disabled=!state.features.extraction;
  $('#guide-ai-hint').textContent=state.features.extraction?'识别接口已配置；是否发送与付费，由你在这里选择。':'尚未配置识别 API。本次可先读取笔记，再手动补充地点。';
  $('#guide-result').textContent=''; showStep(); $('#guide-dialog').showModal();
}
export function updateProduct(state) {
  if(!ctx)return;
  for(const k of ['xhs','google'])$(`#guide-${k}`).textContent=state.connections[k]==='connected'?'· 已连接':'· 待检查';
  if($('#guide-dialog').open){
    if(guideStep===1)$('#guide-next').disabled=['xhs','google'].some(k=>state.connections[k]!=='connected');
    for(const op of state.operations){
      if(op.label==='读取收藏夹'&&op.status==='done'&&!boardOperations.has(op.id)){
        boardOperations.add(op.id);const select=$('#guide-board-picker');select.innerHTML='<option value="">请选择</option>';
        for(const b of op.result){const option=document.createElement('option');option.value=b.url;option.textContent=b.name;select.append(option);}
        $('#guide-board-label').hidden=false;
      }
      if(op.id===guideOperation&&op.status!=='running'){
        guideOperation=null;$('#guide-start').disabled=false;$('#guide-back').disabled=false;
        if(op.status==='failed')$('#guide-result').textContent=`读取未完成：${op.error.message}。可修正后再试。`;
        else if(op.result?.busy)$('#guide-result').textContent='后台已有任务，请等待完成后再试。';
        else{
          const r=op.result;$('#guide-result').textContent=`目录读取 ${r.read} 篇，新增 ${r.added} 篇；本次最多处理 3 篇详情。详情错误 ${r.detailErrors||0}，识别错误 ${r.extractionErrors||0}。${r.truncated?'收藏夹目录尚未完整覆盖。':''}可以开始核对，剩余未读取笔记可后续继续检查。`;
          $('#guide-start').hidden=true;$('#guide-finish').hidden=false;
        }
      }
    }
  }
  if(!prompted){prompted=true;if(!state.notes.length&&!state.settings.onboardingCompletedAt)openGuide();}
}
export function initProduct(context) {
  ctx=context;
  document.addEventListener('click',event=>{
    const b=event.target.closest('button');if(!b)return;
    if(b.dataset.review) return openReview(b.dataset.review,b.dataset.note);
    if(b.id==='open-guide')return openGuide();
    if(b.id==='review-search')return ctx.act(async()=>{await ctx.api(`/api/places/${currentPlace}/browser-search`,{});ctx.toast('在地图里点开正确分店，然后回来读取位置。');},b);
    if(['review-read','review-paste','review-api-search'].includes(b.id))return ctx.act(async()=>{
      const place=currentPlace, token=sequence;candidatesHtml([]);
      const body=b.id==='review-paste'?{mapUrl:$('#review-url').value.trim()}:{};
      if(b.id==='review-paste'&&!body.mapUrl)throw new Error('请先粘贴完整地图链接。');
      const data=await ctx.api(`/api/places/${place}/${b.id==='review-api-search'?'search':'preview'}`,body);
      if(token===sequence&&$('#review-dialog').open)candidatesHtml(b.id==='review-api-search'?data.candidates:[data]);
    },b);
    if(b.id==='review-confirm')return ctx.act(async()=>{
      if(!candidate||!$('#review-ack').checked)throw new Error('请选择候选并核对地址、分店。');
      await ctx.api(`/api/places/${currentPlace}/confirm`,{selectionId:candidate.selectionId,confirmed:true});
      ctx.onReviewed();$('#review-dialog').close();ctx.toast('位置已确认。勾选后，再加入 Google Maps。');
    },b);
    if(b.id==='review-defer')return ctx.act(async()=>{await ctx.api(`/api/places/${currentPlace}/defer`,{deferred:true,reason:$('#defer-reason').value});$('#review-dialog').close();ctx.toast('已留到“稍后核对”，不会进入保存队列。');},b);
    if(b.id==='guide-back'){guideStep=Math.max(0,guideStep-1);return showStep();}
    if(b.id==='guide-next'){
      const f=$('#guide-form'),fields=guideStep===0?['city','targetList']:guideStep===2?['boardUrl']:[];
      if(fields.some(key=>!f.elements[key].reportValidity()))return;
      if(guideStep===1&&['xhs','google'].some(k=>ctx.getState().connections[k]!=='connected'))return;
      guideStep=Math.min(3,guideStep+1);return showStep();
    }
    if(b.id==='guide-boards')return ctx.act(async()=>{await ctx.api('/api/xhs/boards',{});ctx.toast('正在读取收藏夹…');},b);
    if(b.id==='guide-finish')return ctx.act(async()=>{await ctx.api('/api/onboarding/complete',{});$('#guide-dialog').close();ctx.showInbox();},b);
  });
  $('#review-ack').addEventListener('change',confirmEnabled);
  $('#review-dialog').addEventListener('close',()=>{sequence++;candidate=null;});
  $('#guide-board-picker').addEventListener('change',e=>{const select=e.target;if(select.value){const f=$('#guide-form');f.elements.boardUrl.value=select.value;f.elements.boardName.value=select.options[select.selectedIndex].textContent;}});
  $('#guide-form').addEventListener('submit',e=>{
    e.preventDefault();const f=e.target;if(guideStep!==3||guideOperation)return;
    ctx.act(async()=>{
      const settings=ctx.getState().settings;
      await ctx.api('/api/settings',{...settings,city:f.elements.city.value,targetList:f.elements.targetList.value,boardName:f.elements.boardName.value,boardUrl:f.elements.boardUrl.value});ctx.settingsChanged();
      const r=await ctx.api('/api/poll',{extract:f.elements.extract.checked,detailLimit:3});guideOperation=r.operationId;
      $('#guide-result').textContent='正在读取；完成前请保持电脑唤醒。';$('#guide-back').disabled=true;
    },$('#guide-start')).then(()=>{if(guideOperation)$('#guide-start').disabled=true;});
  });
}
