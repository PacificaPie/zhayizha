import { initProduct, updateProduct } from './product.js';
const $ = selector => document.querySelector(selector);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const safeLink = value => { try { const u = new URL(value); return u.protocol === 'https:' ? u.href : ''; } catch { return ''; } };
let state, selected = new Set(), settingsLoaded = false, toastTimer, activeView = 'inbox';
let signature = '', refreshing = false, reviewFilter = 'pending';
const seenOperations = new Set();
const labels = { later:'稍后核对', ready:'位置已确认', needs_match:'待确认位置', queued:'等待保存', running:'正在保存', saved:'已保存', needs_review:'需核对', blocked:'已暂停', failed:'失败', unknown:'未检查', connected:'已连接', awaiting_login:'请完成登录', needs_login:'需要登录' };

async function api(url, body) {
  const response = await fetch(url, body === undefined ? {} : { method:'POST', headers:{ 'Content-Type':'application/json' }, body:JSON.stringify(body) });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || '操作失败，请重试。');
  return data;
}
function toast(message, error = false) {
  const el = $('#toast'); el.textContent = message; el.classList.toggle('error', error); el.hidden = false;
  clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.hidden = true; }, error ? 9000 : 5500);
}
function showView(view) {
  activeView = view;
  for (const name of ['inbox','jobs','settings']) $(`#${name}-view`).hidden = name !== view;
  document.querySelectorAll('[data-view]').forEach(b => { b.classList.toggle('active', b.dataset.view === view); if (b.dataset.view === view) b.setAttribute('aria-current','page'); else b.removeAttribute('aria-current'); });
}
function jobFor(placeId) { return state.jobs.find(j => (j.placeIds || [j.place_id]).includes(placeId) && j.target === state.settings.targetList); }
function canSelect(p) { return p.status === 'ready' && !p.review && !jobFor(p.id); }
function renderSelection() {
  selected = new Set([...selected].filter(id => state.places.some(p => p.id === id && canSelect(p))));
  document.querySelectorAll('input[data-select]').forEach(el => { el.checked = selected.has(el.dataset.select); el.closest('.place').classList.toggle('selected', el.checked); });
  $('#selected-count').textContent = `已选 ${selected.size} 处`;
  $('#target-label').textContent = `保存到「${state.settings.targetList}」`;
  $('#approve').disabled = !selected.size;
  $('#approve').textContent = selected.size ? `加入 Google Maps · ${selected.size}` : '加入 Google Maps';
  $('#selection-bar').hidden = !state.places.length;
  const available = state.places.filter(canSelect).slice(0,50);
  $('#select-all').textContent = available.length && available.every(p => selected.has(p.id)) ? '取消全选' : '全选可保存地点';
  $('#select-all').disabled = !available.length;
}
function placeHtml(p, noteId) {
  const job = jobFor(p.id), status = job?.status || (p.review ? 'later' : p.status);
  const inputId = `place-${noteId}-${p.id}`;
  return `<div class="place ${selected.has(p.id) ? 'selected' : ''}"><input id="${esc(inputId)}" data-select="${esc(p.id)}" type="checkbox" ${selected.has(p.id) ? 'checked' : ''} ${canSelect(p) ? '' : 'disabled'} aria-label="选择 ${esc(p.name)}"><div class="place-main"><div class="place-title"><label for="${esc(inputId)}">${esc(p.name)}</label><span class="badge ${esc(status)}">${esc(labels[status] || status)}</span></div><div class="place-sub">${esc([p.city,p.address].filter(Boolean).join(' · '))}</div>${p.evidence ? `<div class="place-evidence">${esc(p.evidence)}</div>` : ''}<div class="place-actions">${!job ? `<button class="button secondary" data-review="${esc(p.id)}" data-note="${esc(noteId)}">${p.review ? '继续核对' : p.status === 'ready' ? '查看或更改位置' : '核对地图位置'}</button>${p.review ? `<span class="muted">${esc(p.review.reason)}</span>` : ''}` : ''}${p.map_url ? `<a class="button quiet" href="${esc(safeLink(p.map_url))}" target="_blank" rel="noopener noreferrer">查看地图 ↗</a>` : ''}</div></div></div>`;
}
function renderData() {
  $('#trip-title').textContent = state.settings.targetList;
  $('#pending-count').textContent = state.places.filter(p => !jobFor(p.id)).length;
  $('#job-count').textContent = state.jobs.length;
  $('#sync-label').textContent = state.settings.boardUrl ? `${state.settings.boardName || '指定收藏夹'} · ${state.settings.polling ? '自动检查中' : '手动检查'}` : '等待连接收藏夹';
  $('#poll-dot').classList.toggle('on', state.settings.polling);
  const polling = state.polling;
  const pollTime = time => time ? new Date(time).toLocaleString('zh-CN') : '暂无记录';
  $('#last-poll').textContent = polling ? `最近尝试：${pollTime(polling.lastAttemptAt)} · 最近成功读取：${pollTime(polling.lastSuccessAt)}${polling.consecutiveFailures ? ` · 连续失败 ${polling.consecutiveFailures} 次（新记录）` : ''}${polling.latest?.diagnostic ? ` · ${polling.latest.diagnostic.code}` : ''}` : '首次使用请先完成连接设置';
  $('#poll-now').disabled = !state.settings.boardUrl || state.workerBusy;
  if (!state.notes.length) {
    $('#notes').innerHTML = '<div class="empty"><div class="empty-symbol">↗</div><h2>把收藏夹，变成旅行地图</h2><p>先连接小红书并选择收藏夹。新增笔记会出现在这里，你可以按地点勾选，再保存到 Google Maps。</p><div class="actions"><button class="button primary" data-open-settings>开始连接</button><button class="button quiet" data-open-note>先添加一篇笔记</button></div></div>';
  } else {
    $('#notes').innerHTML = state.notes.map(n => {
      const all = state.places.filter(p => p.noteIds.includes(n.id));
      const places = all.filter(p => matchesFilter(p));
      if (!places.length && (all.length || !['pending','all'].includes(reviewFilter))) return '';
      const source = safeLink(n.url);
      return `<article class="note"><div class="note-header"><div><div class="note-title">${esc(n.title)}</div><div class="note-meta">${places.length} 个地点${source ? `<a href="${esc(source)}" target="_blank" rel="noopener noreferrer">查看原笔记 ↗</a>` : ' · 手动添加'}</div></div></div>${n.error ? `<div class="note-error">${esc(n.error)}</div>` : ''}${places.length ? places.map(p => placeHtml(p,n.id)).join('') : `<div class="note-empty">${n.status === 'extracted' ? '这篇笔记没有识别出具体地点，可手动补充。' : '等待提取地点。可以使用自动识别，也可以手动补充。'}</div>`}${n.body ? `<details class="note-body"><summary>查看笔记正文</summary><pre>${esc(n.body)}</pre></details>` : ''}<div class="note-tools"><button class="button quiet" data-extract="${esc(n.id)}" ${state.features.extraction ? '' : 'disabled'}>识别文字与图片</button><button class="button quiet" data-add-place="${esc(n.id)}">＋ 补充地点</button>${!state.features.extraction ? '<span class="note-meta">自动识别待配置 API</span>' : ''}</div></article>`;
    }).join('') || '<div class="empty"><h2>这一栏暂时没有地点</h2><p>可切换筛选查看已确认、稍后核对或已保存的地点。</p></div>';
  }
  $('#jobs').innerHTML = state.jobs.length ? state.jobs.map(j => `<article class="job"><div class="job-info"><strong>${esc(j.expected_name)}</strong><p>目标：${esc(j.target)}</p>${j.error ? `<p class="job-error">${esc(j.error)}</p>` : ''}</div><div class="job-side"><span class="badge ${esc(j.status)}">${esc(labels[j.status] || j.status)}</span>${['blocked','needs_review','failed'].includes(j.status) ? `<button class="button quiet" data-retry="${esc(j.id)}">重新检查并重试</button>` : ''}</div></article>`).join('') : '<div class="empty"><h2>还没有提交地点</h2><p>在待确认页面核对位置、勾选地点后，保存进度会出现在这里。</p></div>';
  $('#events').innerHTML = state.events.map(e => `<div class="event"><time>${new Date(e.time).toLocaleTimeString('zh-CN')}</time><span>${esc(e.message)}</span></div>`).join('') || '<p>暂无活动</p>';
  for (const service of ['xhs','google']) { const badge=$(`#${service}-status`); badge.textContent=labels[state.connections[service]] || '未检查'; badge.className=`badge ${state.connections[service] === 'connected' ? 'ready' : ''}`; }
  $('#ai-capability').textContent = `笔记自动识别：${state.features.extraction ? '已配置，文字与图片将发送到识别服务' : '未配置，可先手动录入地点'}`;
  $('#places-capability').textContent = `Google 地点搜索：${state.features.places ? '已配置' : '未配置，可用浏览器查找并确认位置'}`;
  const purposes = { runtime: '运行识别', eval_text: '文字评测', eval_vision: '图片评测', eval_holdout: '新样本评测' };
  $('#usage-summary').innerHTML = state.usage?.groups.length ? state.usage.groups.map(g => `<p><strong>${esc(purposes[g.purpose] || g.purpose)}</strong>：${g.calls} 次调用，${g.calls_with_usage} 次有完整用量。输入 ${g.input_tokens ?? '未知'} / 输出 ${g.output_tokens ?? '未知'} / 缓存输入 ${g.cached_input_tokens ?? '未知'} tokens（缓存属于输入）。可计价部分 ${g.estimated_cost_nano_usd == null ? '未知' : '$' + (g.estimated_cost_nano_usd / 1e9).toFixed(6)} USD，覆盖 ${g.priced_calls}/${g.calls} 次。</p>`).join('') : '<p>尚无逐次调用记录；历史用量和费用未知。</p>';
  if (!settingsLoaded) {
    const form = $('#settings-form');
    for (const key of ['city','targetList','boardName','boardUrl','pollMinutes']) form.elements[key].value = state.settings[key];
    form.elements.polling.checked = state.settings.polling; settingsLoaded = true;
  }
  $('#review-filters').innerHTML = [['pending','待确认'],['ready','已确认'],['later','稍后核对'],['all','全部']].map(([key,name])=>`<button class="button ${reviewFilter===key?'secondary active':'quiet'}" data-filter="${key}" aria-pressed="${reviewFilter===key}">${name} <small>${state.places.filter(p=>matchesFilter(p,key)).length}</small></button>`).join('');
  updateProduct(state); renderSelection();
}
function matchesFilter(p, filter=reviewFilter) {
  if(filter==='all') return true;
  if(jobFor(p.id)) return false;
  if(filter==='later') return !!p.review;
  if(filter==='ready') return p.status==='ready'&&!p.review;
  return p.status!=='ready'&&!p.review;
}
function showBoards(boards) {
  const picker = $('#board-picker'); picker.innerHTML = '<option value="">请选择</option>';
  boards.forEach(b => { const option = document.createElement('option'); option.value = b.url; option.textContent = b.name; picker.append(option); });
  $('#board-picker-label').hidden = false; showView('settings');
  const match=boards.find(b => b.name === $('#settings-form').elements.boardName.value);
  if (match) { picker.value=match.url; $('#settings-form').elements.boardUrl.value=match.url; toast(`找到「${match.name}」，请保存设置。`); }
  else toast(boards.length ? '收藏夹已读取，请选择并保存设置。' : '尚未找到收藏夹，请先在小红书创建 CDMX。');
}
async function refresh() {
  if (refreshing) return; refreshing=true;
  try {
    state = await api('/api/state');
    const nextSignature=JSON.stringify(state);
    if(nextSignature!==signature){ signature=nextSignature; renderData(); }
    for(const op of state.operations) {
      if(op.status==='running'||seenOperations.has(op.id)) continue;
      seenOperations.add(op.id);
      if(op.status==='failed') toast(op.error.message,true);
      else if(op.label==='读取收藏夹'&&!$('#guide-dialog').open) showBoards(op.result);
      else if(op.result?.message) toast(op.result.message);
      else if(op.label==='检查新增笔记') toast(op.result?.busy ? '后台正在处理，请稍后再检查。' : `读取 ${op.result.read} 篇，新增 ${op.result.added} 篇。`);
      else toast(`${op.label}：已完成`);
    }
  } catch(error) { if(!state) toast(error.message,true); }
  finally { refreshing=false; }
}
async function act(fn, button) {
  if(button) button.disabled=true;
  try{ await fn(); await refresh(); } catch(error){ toast(error.message,true); }
  finally{ if(button?.isConnected) button.disabled=false; if(state) renderSelection(); }
}
document.addEventListener('click', event => {
  const b=event.target.closest('button'); if(!b) return;
  if(b.dataset.filter){reviewFilter=b.dataset.filter;return renderData();}
  if(b.dataset.view) return showView(b.dataset.view);
  if(b.dataset.close) return $(`#${b.dataset.close}`).close();
  if(b.hasAttribute('data-open-settings')) return showView('settings');
  if(b.id==='add-note'||b.hasAttribute('data-open-note')) return $('#note-dialog').showModal();
  if(b.dataset.connect||b.dataset.check) return act(async()=>{const service=b.dataset.connect||b.dataset.check;await api(`/api/connections/${service}/${b.dataset.connect?'open':'check'}`,{});toast('操作已开始，请查看浏览器窗口。');},b);
  if(b.id==='load-boards') return act(async()=>{await api('/api/xhs/boards',{});toast('正在读取收藏夹…');},b);
  if(b.id==='poll-now') return act(async()=>{await api('/api/poll',{});toast('正在检查新增笔记…');},b);
  if(b.dataset.extract) return act(async()=>{await api(`/api/notes/${b.dataset.extract}/extract`,{});toast('识别已开始…');},b);
  if(b.dataset.addPlace){const f=$('#place-form');f.reset();f.elements.noteId.value=b.dataset.addPlace;f.elements.city.value=state.settings.city;return $('#place-dialog').showModal();}
  if(b.dataset.browserSearch) return act(async()=>{await api(`/api/places/${b.dataset.browserSearch}/browser-search`,{});toast('正在打开地图，请点开正确分店的详情页。');},b);
  if(b.dataset.mapLink){const p=state.places.find(p=>p.id===b.dataset.mapLink),f=$('#map-link-form');f.reset();f.elements.placeId.value=p.id;f.elements.mapUrl.value=p.map_url||'';$('#map-link-place').textContent=[p.name,p.address].filter(Boolean).join(' · ');return $('#map-link-dialog').showModal();}
  if(b.dataset.capture) return act(async()=>{const r=await api(`/api/places/${b.dataset.capture}/capture`,{});toast(`已采用浏览器中的地点：${r.name}`);},b);
  if(b.dataset.search) return act(async()=>{
    const id=b.dataset.search,r=await api(`/api/places/${id}/search`,{});
    $('#candidates').innerHTML=r.candidates.length?r.candidates.map(c=>`<div class="candidate"><strong>${esc(c.name)}</strong><p>${esc(c.address)}</p><div class="actions"><button class="button primary" data-match="${esc(id)}" data-place-id="${esc(c.id)}">选择这处地点</button>${safeLink(c.url)?`<a href="${esc(safeLink(c.url))}" target="_blank" rel="noopener noreferrer">查看 Google Maps ↗</a>`:''}</div></div>`).join(''):'<p>没有找到匹配结果。可以改用浏览器查找。</p>';
    $('#candidate-dialog').showModal();
  },b);
  if(b.dataset.match) return act(async()=>{await api(`/api/places/${b.dataset.match}/match`,{placeId:b.dataset.placeId});$('#candidate-dialog').close();toast('地图位置已确认，可以勾选保存。');},b);
  if(b.id==='select-all'){const available=state.places.filter(canSelect).slice(0,50);selected=new Set(available.every(p=>selected.has(p.id))?[]:available.map(p=>p.id));return renderSelection();}
  if(b.id==='approve') return act(async()=>{const ids=[...selected];await api('/api/approve',{ids});selected.clear();showView('jobs');toast(`已提交 ${ids.length} 个地点，电脑开始保存。`);},b);
  if(b.dataset.retry) return act(async()=>{await api(`/api/jobs/${b.dataset.retry}/retry`,{});toast('任务将先检查远端状态，再决定是否保存。');},b);
});
document.addEventListener('change',event=>{const el=event.target;if(el.dataset.select){if(el.checked)selected.add(el.dataset.select);else selected.delete(el.dataset.select);renderSelection();}if(el.id==='board-picker'&&el.value){$('#settings-form').elements.boardUrl.value=el.value;$('#settings-form').elements.boardName.value=el.options[el.selectedIndex].textContent;}});
$('#settings-form').addEventListener('submit',event=>{event.preventDefault();const f=event.target;act(async()=>{await api('/api/settings',{city:f.elements.city.value,targetList:f.elements.targetList.value,boardName:f.elements.boardName.value,boardUrl:f.elements.boardUrl.value,pollMinutes:Number(f.elements.pollMinutes.value),polling:f.elements.polling.checked});settingsLoaded=false;toast('设置已保存。');},f.querySelector('[type=submit]'));});
$('#note-form').addEventListener('submit',event=>{event.preventDefault();const f=event.target;act(async()=>{
  const files=[...f.elements.images.files];if(files.length>12||files.reduce((n,file)=>n+file.size,0)>10*1024*1024)throw new Error('最多上传 12 张截图，总计不超过 10 MB。');
  const images=await Promise.all(files.map(file=>new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(new Error('截图读取失败。'));reader.readAsDataURL(file);}))); 
  await api('/api/notes',{title:f.elements.title.value,body:f.elements.body.value,url:f.elements.url.value,images});f.reset();$('#note-dialog').close();showView('inbox');toast('笔记已添加，可以开始提取或补充地点。');
},f.querySelector('[type=submit]'));});
$('#place-form').addEventListener('submit',event=>{event.preventDefault();const f=event.target;act(async()=>{await api(`/api/notes/${f.elements.noteId.value}/places`,{name:f.elements.name.value,city:f.elements.city.value,address:f.elements.address.value,evidence:f.elements.evidence.value});$('#place-dialog').close();toast('地点已添加，请先确认地图位置。');},f.querySelector('button.primary'));});
$('#map-link-form').addEventListener('submit',event=>{event.preventDefault();const f=event.target;act(async()=>{const r=await api(`/api/places/${f.elements.placeId.value}/capture`,{mapUrl:f.elements.mapUrl.value.trim()});$('#map-link-dialog').close();toast(`已采用地图地点：${r.name}，可以勾选保存。`);},f.querySelector('[type=submit]'));});
initProduct({api,toast,act,refresh,getState:()=>state,settingsChanged:()=>{settingsLoaded=false;},onReviewed:()=>{reviewFilter='ready';},showInbox:()=>showView('inbox')});
await refresh();setInterval(refresh,3000);
