#!/bin/zsh
cd "${0:A:h}"
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
if ! command -v node >/dev/null || ! node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)' 2>/dev/null; then
  print '需要 Node.js 22.13 或更新版本 / Node.js 22.13+ is required.'
  print '安装地址 / Download: https://nodejs.org/en/download'
  read '?按回车关闭 / Press Return to close: '
  exit 1
fi
if [[ ! -d /Applications/Google\ Chrome.app && ! -d "$HOME/Applications/Google Chrome.app" ]]; then
  print '请先安装 Google Chrome / Please install Google Chrome first.'
  read '?按回车关闭 / Press Return to close: '
  exit 1
fi
if [[ ! -d node_modules/express || ! -d node_modules/playwright ]]; then
  print '首次启动：安装固定版本依赖 / First launch: installing pinned dependencies…'
  npm ci --omit=dev --ignore-scripts || { read '?安装失败。按回车关闭 / Installation failed. Press Return: '; exit 1; }
fi
node --env-file-if-exists=.env scripts/launch-release.js
if [[ $? -ne 0 ]]; then read '?启动失败。按回车关闭 / Start failed. Press Return: '; fi
