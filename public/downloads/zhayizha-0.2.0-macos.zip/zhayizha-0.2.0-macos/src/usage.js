import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';

// Standard Responses API prices, checked 2026-10-12; these are estimates, not billing receipts.
export const PRICING = Object.freeze({ version: 'openai-standard-2026-10-12', checkedAt: '2026-10-12',
  source: 'https://developers.openai.com/api/docs/models/gpt-4.1-mini', currency: 'USD',
  inputPerMillion: 0.40, cachedInputPerMillion: 0.10, outputPerMillion: 1.60 });
const token = n => Number.isSafeInteger(n) && n >= 0 ? n : null;
const identifier = value => typeof value === 'string' && /^[a-zA-Z0-9_.:-]{1,200}$/.test(value) ? value : null;
export function usageFields(json) {
  const u = json?.usage;
  return { response_id: identifier(json?.id), returned_model: json?.model == null ? null : identifier(json.model) || 'unknown',
    provider_status: ['completed', 'incomplete', 'failed', 'cancelled', 'queued', 'in_progress'].includes(json?.status) ? json.status : null,
    service_tier: json?.service_tier == null ? null : identifier(json.service_tier) || 'unknown',
    incomplete_reason: ['max_output_tokens', 'content_filter'].includes(json?.incomplete_details?.reason) ? json.incomplete_details.reason : null,
    input_tokens: token(u?.input_tokens), output_tokens: token(u?.output_tokens),
    cached_input_tokens: token(u?.input_tokens_details?.cached_tokens), total_tokens: token(u?.total_tokens),
    reasoning_tokens: token(u?.output_tokens_details?.reasoning_tokens) };
}
export function priceUsage(row) {
  const model = row.returned_model || row.requested_model;
  const supported = ['gpt-4.1-mini', 'gpt-4.1-mini-2025-04-14'].includes(model)
    && [null, undefined, 'default'].includes(row.service_tier);
  const pricing = supported ? PRICING : null;
  const { input_tokens: input, output_tokens: output, cached_input_tokens: cached } = row;
  const complete = [input, output, cached].every(n => token(n) !== null) && cached <= input
    && (row.total_tokens == null || row.total_tokens === input + output);
  const cost = supported && complete ? (input - cached) * 400 + cached * 100 + output * 1600 : null;
  return { pricing_version: pricing?.version || null, pricing: pricing ? JSON.stringify(pricing) : null,
    estimated_cost_nano_usd: Number.isSafeInteger(cost) ? cost : null,
    cost_status: !supported ? 'unpriced_model_or_tier' : !complete || !Number.isSafeInteger(cost) ? 'usage_missing_or_invalid' : 'estimated_from_usage' };
}

// Can share the runtime connection or open independently for evaluation. No job recovery side effects.
export function createUsageLedger(db) {
  db.exec(`CREATE TABLE IF NOT EXISTS model_calls (
    id TEXT PRIMARY KEY, purpose TEXT NOT NULL, run_id TEXT, case_id TEXT, note_id TEXT,
    requested_model TEXT NOT NULL, returned_model TEXT, started_at INTEGER NOT NULL, finished_at INTEGER,
    duration_ms INTEGER, status TEXT NOT NULL, http_status INTEGER, provider_status TEXT, response_id TEXT,
    request_id TEXT, service_tier TEXT, incomplete_reason TEXT, error_code TEXT,
    input_tokens INTEGER, output_tokens INTEGER, cached_input_tokens INTEGER, total_tokens INTEGER, reasoning_tokens INTEGER,
    pricing_version TEXT, pricing TEXT, estimated_cost_nano_usd INTEGER, cost_status TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS model_calls_started ON model_calls(started_at);`);
  const update = (id, fields) => {
    const keys = Object.keys(fields);
    db.prepare(`UPDATE model_calls SET ${keys.map(k => `${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k => fields[k] ?? null), id);
  };
  return {
    start({ purpose = 'runtime', runId = null, caseId = null, noteId = null, model }) {
      if (!['runtime', 'eval_text', 'eval_vision', 'eval_holdout'].includes(purpose)) throw new Error('Invalid usage purpose');
      const id = randomUUID();
      db.prepare("INSERT INTO model_calls(id,purpose,run_id,case_id,note_id,requested_model,started_at,status,cost_status) VALUES(?,?,?,?,?,?,?,'requesting','usage_missing_or_invalid')")
        .run(id, purpose, runId, caseId, noteId, model, Date.now());
      update(id, priceUsage({ requested_model: model }));
      return id;
    },
    received(id, { json, httpStatus, requestId }) {
      const fields = usageFields(json);
      const row = db.prepare('SELECT requested_model FROM model_calls WHERE id=?').get(id);
      update(id, { ...fields, ...priceUsage({ ...row, ...fields }), http_status: httpStatus, request_id: identifier(requestId), status: 'received' });
    },
    finish(id, { status, durationMs, errorCode = null }) {
      update(id, { status, duration_ms: durationMs, error_code: identifier(errorCode), finished_at: Date.now() });
    },
    get(id) { const row = db.prepare('SELECT * FROM model_calls WHERE id=?').get(id); return row ? { ...row, pricing: row.pricing ? JSON.parse(row.pricing) : null } : null; },
    summary() {
      const groups = db.prepare(`SELECT purpose, count(*) calls,
        sum(CASE WHEN input_tokens IS NOT NULL AND output_tokens IS NOT NULL AND cached_input_tokens IS NOT NULL THEN 1 ELSE 0 END) calls_with_usage,
        sum(CASE WHEN estimated_cost_nano_usd IS NOT NULL THEN 1 ELSE 0 END) priced_calls,
        sum(CASE WHEN status='completed' THEN 1 ELSE 0 END) completed_calls,
        sum(input_tokens) input_tokens, sum(output_tokens) output_tokens, sum(cached_input_tokens) cached_input_tokens,
        sum(estimated_cost_nano_usd) estimated_cost_nano_usd FROM model_calls GROUP BY purpose`).all();
      return { historicalUsage: 'unknown_before_instrumentation', costBasis: 'usage_estimate_not_invoice', groups,
        recent: db.prepare('SELECT id FROM model_calls ORDER BY started_at DESC,rowid DESC LIMIT 30').all().map(r => this.get(r.id)) };
    },
  };
}
export function openUsageLedger(filename) {
  const db = new DatabaseSync(filename); db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  const ledger = createUsageLedger(db);
  return { ...ledger, close: () => db.close() };
}
