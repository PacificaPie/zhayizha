import { DatabaseSync } from 'node:sqlite';
import { randomUUID } from 'node:crypto';
import { assert } from './errors.js';
import { mapsIdentity } from './maps-identity.js';
import { createUsageLedger } from './usage.js';

export function createStore(filename) {
  const db = new DatabaseSync(filename);
  db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
    CREATE TABLE IF NOT EXISTS settings (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notes (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, url TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '',
      images TEXT NOT NULL DEFAULT '[]', status TEXT NOT NULL DEFAULT 'new', error TEXT,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS places (
      id TEXT PRIMARY KEY, source_key TEXT UNIQUE NOT NULL, name TEXT NOT NULL, city TEXT NOT NULL,
      address TEXT NOT NULL DEFAULT '', evidence TEXT NOT NULL DEFAULT '', place_id TEXT,
      map_url TEXT, status TEXT NOT NULL DEFAULT 'needs_match', created_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS note_places (
      note_id TEXT REFERENCES notes(id), place_id TEXT REFERENCES places(id), PRIMARY KEY(note_id,place_id));
    CREATE TABLE IF NOT EXISTS place_reviews (
      place_id TEXT PRIMARY KEY REFERENCES places(id), decision TEXT NOT NULL, reason TEXT NOT NULL,
      updated_at INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, place_id TEXT REFERENCES places(id), target TEXT NOT NULL, identity TEXT NOT NULL,
      map_url TEXT NOT NULL, expected_name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'queued',
      attempts INTEGER NOT NULL DEFAULT 0, error TEXT, next_at INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, UNIQUE(target,identity));
    CREATE TABLE IF NOT EXISTS events (id INTEGER PRIMARY KEY AUTOINCREMENT, time INTEGER NOT NULL, kind TEXT NOT NULL, message TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS poll_runs (
      id TEXT PRIMARY KEY, trigger TEXT NOT NULL, started_at INTEGER NOT NULL, finished_at INTEGER,
      status TEXT NOT NULL, stage TEXT NOT NULL, read_count INTEGER, added_count INTEGER,
      truncated INTEGER, detail_errors INTEGER NOT NULL DEFAULT 0, extraction_errors INTEGER NOT NULL DEFAULT 0,
      diagnostic TEXT);
    CREATE TABLE IF NOT EXISTS job_places (
      job_id TEXT REFERENCES jobs(id), place_id TEXT REFERENCES places(id), PRIMARY KEY(job_id,place_id));
    CREATE TABLE IF NOT EXISTS job_attempts (
      job_id TEXT NOT NULL REFERENCES jobs(id), attempt INTEGER NOT NULL,
      started_at INTEGER NOT NULL, finished_at INTEGER NOT NULL, total_ms INTEGER NOT NULL,
      status TEXT NOT NULL, timings TEXT NOT NULL, result TEXT, error_code TEXT,
      PRIMARY KEY(job_id,attempt));
  `);
  const usage = createUsageLedger(db);
  db.prepare("UPDATE model_calls SET status='interrupted',finished_at=?,error_code='PROCESS_INTERRUPTED' WHERE purpose='runtime' AND status IN ('requesting','received')").run(Date.now());
  db.prepare("UPDATE poll_runs SET status='interrupted',finished_at=?,diagnostic=? WHERE status='running'")
    .run(Date.now(), JSON.stringify({ code: 'PROCESS_INTERRUPTED' }));
  db.exec('INSERT OR IGNORE INTO job_places SELECT id,place_id FROM jobs');
  db.prepare('INSERT OR IGNORE INTO settings VALUES(1,?)').run(JSON.stringify({ city: 'Ciudad de México, Mexico', boardUrl: '', boardName: 'CDMX', targetList: 'CDMX', pollMinutes: 15, polling: false, lastPollAt: null }));
  // A interrupted write is uncertain. Do not replay it without checking remote state.
  const recovered = db.prepare("UPDATE jobs SET status='needs_review', error='上次保存中断，重新检查目标列表后再重试。' WHERE status='running'").run();
  if (recovered.changes) db.prepare("UPDATE jobs SET status='blocked',error='上次保存中断，请检查结果后重试。' WHERE status='queued'").run();
  const getSettings = () => JSON.parse(db.prepare('SELECT value FROM settings WHERE id=1').get().value);
  const event = (kind, message) => db.prepare('INSERT INTO events(time,kind,message) VALUES(?,?,?)').run(Date.now(), kind, message);
  const transaction = fn => { db.exec('BEGIN IMMEDIATE'); try { const result = fn(); db.exec('COMMIT'); return result; } catch (error) { db.exec('ROLLBACK'); throw error; } };
  return {
    db, event, getSettings, usage,
    startPoll(trigger) {
      const id = randomUUID();
      db.prepare("INSERT INTO poll_runs(id,trigger,started_at,status,stage) VALUES(?,?,?,'running','browser_session')").run(id, trigger, Date.now());
      return id;
    },
    pollStage(id, stage) { db.prepare('UPDATE poll_runs SET stage=? WHERE id=?').run(stage, id); },
    finishPoll(id, { status, result = {}, diagnostic = null }) {
      db.prepare('UPDATE poll_runs SET finished_at=?,status=?,read_count=?,added_count=?,truncated=?,detail_errors=?,extraction_errors=?,diagnostic=? WHERE id=?')
        .run(Date.now(), status, result.read ?? null, result.added ?? null, result.truncated == null ? null : Number(result.truncated),
          result.detailErrors || 0, result.extractionErrors || 0, diagnostic ? JSON.stringify(diagnostic) : null, id);
    },
    pollStatus() {
      const latest = db.prepare('SELECT * FROM poll_runs ORDER BY started_at DESC,rowid DESC LIMIT 1').get();
      const success = db.prepare("SELECT max(time) time FROM events WHERE kind='poll'").get().time;
      // Only newly instrumented runs support a failure streak; old generic events are ambiguous.
      const lastGood = db.prepare("SELECT max(rowid) id FROM poll_runs WHERE status IN ('success','partial')").get().id || 0;
      const failures = db.prepare("SELECT count(*) n FROM poll_runs WHERE rowid>? AND status IN ('failed','interrupted')").get(lastGood).n;
      return { lastAttemptAt: latest?.started_at || getSettings().lastPollAt || null, lastSuccessAt: success,
        consecutiveFailures: failures, failureHistoryComplete: false,
        latest: latest ? { ...latest, diagnostic: latest.diagnostic ? JSON.parse(latest.diagnostic) : null } : null };
    },
    settings(patch) { const next = { ...getSettings(), ...patch }; db.prepare('UPDATE settings SET value=? WHERE id=1').run(JSON.stringify(next)); return next; },
    note(id) { const row = db.prepare('SELECT * FROM notes WHERE id=?').get(id); return row ? { ...row, images: JSON.parse(row.images) } : null; },
    addNote(note) {
      const now = Date.now();
      const result = db.prepare('INSERT OR IGNORE INTO notes(id,title,url,body,images,created_at,updated_at) VALUES(?,?,?,?,?,?,?)')
        .run(note.id || randomUUID(), note.title, note.url || '', note.body || '', JSON.stringify(note.images || []), now, now);
      // Refresh the currently visible access token without overwriting extracted content.
      if (!result.changes && note.url) db.prepare('UPDATE notes SET url=?,updated_at=? WHERE id=?').run(note.url, now, note.id);
      return result.changes > 0;
    },
    updateNote(id, { title, body, images, status, error = null }) {
      const old = this.note(id); assert(old, 'NOT_FOUND', '笔记不存在。', 404);
      db.prepare('UPDATE notes SET title=?,body=?,images=?,status=?,error=?,updated_at=? WHERE id=?')
        .run(title ?? old.title, body ?? old.body, JSON.stringify(images ?? old.images), status ?? old.status, error, Date.now(), id);
    },
    addPlaces(noteId, places) {
      assert(this.note(noteId), 'NOT_FOUND', '笔记不存在。', 404);
      return transaction(() => places.map(place => {
        // Keep separate branches separate. Merge only an identical name/address/city tuple.
        const key = [place.address ? '' : noteId, place.name, place.address || '', place.city].map(v => v.normalize('NFKC').trim().toLocaleLowerCase()).join('|');
        const id = db.prepare('SELECT id FROM places WHERE source_key=?').get(key)?.id || randomUUID();
        db.prepare('INSERT OR IGNORE INTO places(id,source_key,name,city,address,evidence,created_at) VALUES(?,?,?,?,?,?,?)')
          .run(id, key, place.name.trim(), place.city.trim(), place.address || '', place.evidence || '', Date.now());
        db.prepare('INSERT OR IGNORE INTO note_places VALUES(?,?)').run(noteId, id);
        return id;
      }));
    },
    place(id) { return db.prepare('SELECT * FROM places WHERE id=?').get(id); },
    defer(id, deferred, reason = '') {
      assert(this.place(id), 'NOT_FOUND', '地点不存在。', 404);
      assert(!db.prepare('SELECT 1 FROM job_places WHERE place_id=?').get(id), 'JOB_EXISTS', '该地点已有保存记录，请在同步记录中处理。');
      if (deferred) db.prepare("INSERT INTO place_reviews VALUES(?,'later',?,?) ON CONFLICT(place_id) DO UPDATE SET decision='later',reason=excluded.reason,updated_at=excluded.updated_at").run(id, reason, Date.now());
      else db.prepare('DELETE FROM place_reviews WHERE place_id=?').run(id);
    },
    linkSources(id, noteIds) {
      assert(this.place(id), 'NOT_FOUND', '地点不存在。', 404);
      return transaction(() => { for (const noteId of noteIds) {
        assert(this.note(noteId), 'NOT_FOUND', '笔记不存在。', 404);
        db.prepare('INSERT OR IGNORE INTO note_places VALUES(?,?)').run(noteId, id);
      } });
    },
    match(id, { placeId = null, mapUrl }) {
      assert(this.place(id), 'NOT_FOUND', '地点不存在。', 404);
      assert(!db.prepare("SELECT j.id FROM jobs j JOIN job_places jp ON jp.job_id=j.id WHERE jp.place_id=? AND j.status IN ('queued','running','blocked','needs_review')").get(id), 'JOB_EXISTS', '这个地点已在保存队列中，请先处理该任务。');
      db.prepare("UPDATE places SET place_id=?,map_url=?,status='ready' WHERE id=?").run(placeId, mapUrl, id);
      db.prepare('DELETE FROM place_reviews WHERE place_id=?').run(id);
    },
    approve(ids) {
      const target = getSettings().targetList.trim();
      assert(target, 'NO_TARGET', '请设置目标 Google Maps 列表名称。');
      return transaction(() => ids.map(id => {
        const place = this.place(id);
        assert(place?.status === 'ready' && place.map_url, 'NOT_READY', '请先确认所选地点对应的地图位置。');
        assert(!db.prepare("SELECT 1 FROM place_reviews WHERE place_id=? AND decision='later'").get(id), 'DEFERRED', '暂存待核对的地点需要恢复并确认后才能保存。');
        const identity = mapsIdentity(place.map_url, place.place_id);
        // Compare legacy rows too, without changing their frozen audit records.
        const existing = db.prepare('SELECT * FROM jobs WHERE target=?').all(target).find(j =>
          j.identity === identity || mapsIdentity(j.map_url, j.identity.startsWith('google:') ? j.identity.slice(7) : null) === identity);
        if (existing) {
          db.prepare('INSERT OR IGNORE INTO job_places VALUES(?,?)').run(existing.id, id);
          return existing.id;
        }
        const jobId = randomUUID(), now = Date.now();
        db.prepare('INSERT INTO jobs(id,place_id,target,identity,map_url,expected_name,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)')
          .run(jobId, id, target, identity, place.map_url, place.name, now, now);
        db.prepare('INSERT INTO job_places VALUES(?,?)').run(jobId, id);
        return jobId;
      }));
    },
    claim() {
      return transaction(() => {
        const row = db.prepare("SELECT * FROM jobs WHERE status='queued' AND next_at<=? ORDER BY created_at LIMIT 1").get(Date.now());
        if (!row) return null;
        db.prepare("UPDATE jobs SET status='running',attempts=attempts+1,updated_at=? WHERE id=?").run(Date.now(), row.id);
        return { ...row, status: 'running', attempts: row.attempts + 1 };
      });
    },
    finish(id, status, error = null) { db.prepare('UPDATE jobs SET status=?,error=?,updated_at=? WHERE id=?').run(status, error, Date.now(), id); },
    recordAttempt(job, data) {
      db.prepare('INSERT INTO job_attempts(job_id,attempt,started_at,finished_at,total_ms,status,timings,result,error_code) VALUES(?,?,?,?,?,?,?,?,?)')
        .run(job.id, job.attempts, data.startedAt, Date.now(), data.totalMs, data.status, JSON.stringify(data.timings), data.result ? JSON.stringify(data.result) : null, data.errorCode || null);
    },
    retry(id) {
      assert(db.prepare("SELECT id FROM jobs WHERE id=? AND status IN ('blocked','needs_review','failed')").get(id), 'NOT_RETRYABLE', '这个任务当前不需要重试。');
      db.prepare("UPDATE jobs SET status='queued',error=NULL,next_at=0,updated_at=? WHERE id=?").run(Date.now(), id);
    },
    snapshot() {
      return {
        settings: getSettings(),
        polling: this.pollStatus(),
        usage: usage.summary(),
        notes: db.prepare('SELECT id,title,url,body,status,error,created_at FROM notes ORDER BY created_at DESC').all(),
        places: db.prepare('SELECT * FROM places ORDER BY created_at').all().map(p => ({ ...p,
          review: db.prepare('SELECT decision,reason,updated_at FROM place_reviews WHERE place_id=?').get(p.id) || null,
          noteIds: db.prepare('SELECT note_id FROM note_places WHERE place_id=?').all(p.id).map(n => n.note_id) })),
        jobs: db.prepare('SELECT * FROM jobs ORDER BY created_at DESC').all().map(j => ({ ...j,
          placeIds: db.prepare('SELECT place_id FROM job_places WHERE job_id=?').all(j.id).map(p => p.place_id) })),
        events: db.prepare('SELECT * FROM events ORDER BY id DESC LIMIT 30').all(),
        attempts: db.prepare('SELECT * FROM job_attempts ORDER BY started_at DESC LIMIT 100').all().map(a => ({ ...a, timings: JSON.parse(a.timings), result: a.result ? JSON.parse(a.result) : null })),
      };
    },
    close() { db.close(); },
  };
}
