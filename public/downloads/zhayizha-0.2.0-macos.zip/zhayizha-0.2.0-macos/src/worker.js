import { config } from './config.js';
import { AppError, publicError, errorDiagnostic } from './errors.js';

export class Worker {
  busy = false; timer = null; stopped = false;
  extracting = new Set();
  lastTickAt = Date.now();
  pollResumeAt = 0;
  constructor(store, xhs, google, extract) { Object.assign(this, { store, xhs, google, extract }); }
  start() { this.stopped = false; this.timer = setInterval(() => { void this.tick().catch(error => {
    // Unexpected runtime failures must not silently continue on the next tick.
    this.stop();
    try {
      this.store.settings({ polling: false });
      this.store.db.prepare("UPDATE jobs SET status='blocked',error='后台运行异常，检查后重试。' WHERE status='queued'").run();
      this.store.event('error', `后台已暂停：${publicError(error).message}`);
      console.error(JSON.stringify({ kind: 'worker_failure', time: Date.now(), ...errorDiagnostic(error) }));
    } catch { console.error('后台已暂停：无法写入本地状态。'); }
  }); }, 5000); this.timer.unref(); }
  stop() { this.stopped = true; clearInterval(this.timer); }
  async extractNote(id) {
    if (this.extracting.has(id)) throw new AppError('EXTRACTION_BUSY', '这篇笔记正在识别中，请稍等。', 409);
    this.extracting.add(id);
    const note = this.store.note(id);
    try {
      const places = await this.extract(note, this.store.getSettings().city, { usageLedger: this.store.usage, purpose: 'runtime' });
      this.store.addPlaces(id, places);
      this.store.updateNote(id, { status: 'extracted' });
      this.store.event('extract', `「${note.title}」识别出 ${places.length} 个地点，等待位置确认。`);
    } catch (error) {
      this.store.updateNote(id, { status: 'needs_extraction', error: publicError(error).message });
      throw error;
    } finally { this.extracting.delete(id); }
  }
  async poll({ extract = true, trigger = 'manual', detailLimit = 10 } = {}) {
    const id = this.store.startPoll(trigger);
    const result = { read: null, added: 0, truncated: null, detailErrors: 0, extractionErrors: 0 };
    const onStage = stage => this.store.pollStage(id, stage);
    try {
      await this.collect({ extract, result, onStage, pollId: id, detailLimit });
      this.store.finishPoll(id, { status: result.detailErrors || result.extractionErrors ? 'partial' : 'success', result });
      this.store.event('poll', `读取 ${result.read} 篇笔记，新增 ${result.added} 篇。${result.truncated ? '本轮读取范围有限，尚未确认完整历史。' : ''}${result.detailErrors || result.extractionErrors ? `详情失败 ${result.detailErrors} 篇，识别失败 ${result.extractionErrors} 篇。` : ''}`);
      return result;
    } catch (error) {
      const diagnostic = errorDiagnostic(error);
      this.store.finishPoll(id, { status: 'failed', result, diagnostic });
      if (['AUTH_REQUIRED','VERIFICATION_REQUIRED','PAGE_CHANGED'].includes(error.code)) this.store.settings({ polling: false });
      this.store.event('error', `检查失败 [${diagnostic.code}]：${publicError(error).message}`);
      console.error(JSON.stringify({ kind: 'poll_failure', pollId: id, time: Date.now(), ...diagnostic }));
      error.recorded = true;
      throw error;
    } finally { this.store.settings({ lastPollAt: Date.now() }); }
  }
  async collect({ extract, result: counts, onStage, pollId, detailLimit }) {
    const settings = this.store.getSettings();
    const result = await this.xhs.notes(settings.boardUrl, { onStage });
    counts.read = result.notes.length; counts.truncated = !!result.truncated;
    let added = 0;
    for (const note of result.notes) if (this.store.addNote(note)) added++;
    counts.added = added;
    // Retry incomplete details from previous runs, not just IDs first seen this time.
    const pending = this.store.snapshot().notes.filter(n => result.notes.some(r => r.id === n.id) && ['new', 'needs_detail'].includes(n.status)).slice(0, detailLimit);
    for (const note of pending) {
      if (this.stopped) throw new AppError('POLL_INTERRUPTED', '检查已停止，尚未完成的笔记已保留。');
      try {
        onStage('note_detail');
        const detail = await this.xhs.detail(note);
        this.store.updateNote(note.id, { ...detail, status: 'needs_extraction' });
      } catch (error) {
        counts.detailErrors++;
        this.store.updateNote(note.id, { status: 'needs_detail', error: publicError(error).message });
        if (['AUTH_REQUIRED','VERIFICATION_REQUIRED','PAGE_CHANGED'].includes(error.code)) throw error;
        this.store.event('error', `笔记详情读取失败 [${errorDiagnostic(error).code}]，已保留待重试。`);
        console.error(JSON.stringify({ kind: 'poll_detail_failure', pollId, noteId: note.id, time: Date.now(), ...errorDiagnostic(error) }));
        continue;
      }
      if (extract && config.openaiKey) {
        onStage('note_extraction');
        try { await this.extractNote(note.id); } catch (error) { counts.extractionErrors++; this.store.event('error', publicError(error).message); }
      }
    }
    onStage('completed');
  }
  async pollNow(options) {
    if (this.busy) return { busy: true };
    this.busy = true;
    try { return await this.poll(options); }
    finally { this.busy = false; }
  }
  async tick() {
    const now = Date.now(), gapMs = now - this.lastTickAt; this.lastTickAt = now;
    if (gapMs > 60000) {
      // A short maintenance wake often cannot load a browser page. Require a minute of
      // uninterrupted timer activity before the next scheduled read; manual reads still work.
      this.pollResumeAt = now + 60000;
      this.store.event('runtime', `后台调度间隔 ${Math.round(gapMs / 1000)} 秒；可能发生休眠或进程停顿，不计作连续运行。`);
      console.log(JSON.stringify({ kind: 'scheduler_gap', time: now, gapMs }));
    }
    if (this.busy || this.stopped) return;
    this.busy = true;
    try {
      const job = this.store.claim();
      if (job) {
        const startedAt = Date.now(), started = performance.now(), timings = [];
        let attemptResult, attemptError;
        try {
          const result = await this.google.save(job, { onTiming: phase => timings.push(phase) });
          attemptResult = result;
          this.store.finish(job.id, 'saved');
          this.store.event('saved', `${job.expected_name}：${result.alreadySaved ? '已在目标列表中' : '已核实保存成功'}。`);
        } catch (error) {
          attemptError = error;
          const block = ['AUTH_REQUIRED','VERIFICATION_REQUIRED','BROWSER_START'].includes(error.code);
          this.store.finish(job.id, block ? 'blocked' : 'needs_review', publicError(error).message);
          // Pause remaining writes on any uncertain UI result. They require an explicit resume.
          this.store.db.prepare("UPDATE jobs SET status='blocked',error='前一个保存任务需要处理，请检查后逐项重试。' WHERE status='queued'").run();
          this.store.event('error', publicError(error).message);
        } finally {
          this.store.recordAttempt(job, { startedAt, totalMs: Math.round(performance.now() - started), timings,
            status: attemptError ? 'failed' : 'saved', result: attemptResult, errorCode: attemptError?.code || (attemptError ? 'UNKNOWN' : null) });
        }
        return;
      }
      const s = this.store.getSettings();
      if (Date.now() >= this.pollResumeAt && s.polling && s.boardUrl && (!s.lastPollAt || Date.now() - s.lastPollAt >= s.pollMinutes * 60000)) {
        try { await this.poll({ trigger: 'scheduled' }); }
        catch (error) { if (!error.recorded) throw error; }
      }
    } finally { this.busy = false; }
  }
}
