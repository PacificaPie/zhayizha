import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { randomUUID } from 'node:crypto';
import { config, root, dataDir } from './config.js';
import { createStore } from './store.js';
import { AppError, assert, publicError, errorDiagnostic } from './errors.js';
import { BrowserSessions } from './connectors/browser.js';
import { XhsConnector, boardIdFromUrl } from './connectors/xhs.js';
import { GoogleConnector, mapSearchUrl } from './connectors/google.js';
import { extractPlaces, searchPlaces } from './connectors/extraction.js';
import { Worker } from './worker.js';
import { acquireLock } from './lock.js';
import { CandidateSessions } from './review.js';
import { evidenceImage } from './evidence.js';

assert(['127.0.0.1', 'localhost', '::1'].includes(config.host), 'LOCAL_ONLY', '当前验证版只允许绑定本机。远程访问需要先接入认证。');
const releaseLock = acquireLock(dataDir);
process.on('exit', releaseLock);
const store = createStore(path.join(dataDir, 'rednote-maps.sqlite'));
const sessions = new BrowserSessions();
const xhs = new XhsConnector(sessions), google = new GoogleConnector(sessions);
const worker = new Worker(store, xhs, google, extractPlaces);
const candidates = new Map();
const reviews = new CandidateSessions();
const operations = new Map();
const app = express();
app.disable('x-powered-by');
app.use((req, res, next) => {
  const allowed = ['127.0.0.1', 'localhost', '[::1]'].map(h => `${h}:${config.port}`);
  if (!allowed.includes(req.headers.host)) return res.status(403).json({ error: { message: '请求地址不受支持。' } });
  const origin = req.headers.origin;
  if (origin && origin !== `http://${req.headers.host}`) return res.status(403).json({ error: { message: '不允许跨站访问本机服务。' } });
  if (req.headers['sec-fetch-site'] === 'cross-site') return res.status(403).end();
  if (req.method !== 'GET' && !req.is('application/json')) return res.status(415).end();
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  res.setHeader('Cache-Control', 'no-store');
  next();
});
app.use(express.json({ limit: '18mb' }));
const text = (value, max = 500) => typeof value === 'string' ? value.trim().slice(0, max) : '';
function operation(label, fn) {
  const id = randomUUID(); operations.set(id, { id, label, status: 'running', time: Date.now() });
  Promise.resolve().then(fn).then(result => operations.set(id, { id, label, status: 'done', result, time: Date.now() }))
    .catch(error => {
      operations.set(id, { id, label, status: 'failed', error: publicError(error), time: Date.now() });
      if (!error.recorded) {
        store.event('error', publicError(error).message);
        console.error(JSON.stringify({ kind: 'operation_failure', operationId: id, time: Date.now(), ...errorDiagnostic(error) }));
      }
    });
  for (const [key, value] of operations) if (value.status !== 'running' && Date.now() - value.time > 3600000) operations.delete(key);
  return { operationId: id };
}
app.get('/api/state', (req, res) => res.json({ ...store.snapshot(), connections: sessions.states,
  features: { extraction: Boolean(config.openaiKey), places: Boolean(config.googleKey), localOnly: true },
  workerBusy: worker.busy, operations: Array.from(operations.values()).slice(-10),
  workerStatus: { stopped: worker.stopped, lastTickAt: worker.lastTickAt, pollResumeAt: worker.pollResumeAt },
}));
app.get('/api/usage', (req, res) => res.json(store.usage.summary()));
app.post('/api/settings', (req, res) => {
  const b = req.body;
  const city = text(b.city), boardName = text(b.boardName), targetList = text(b.targetList, 150), boardUrl = text(b.boardUrl, 1500);
  assert(city && targetList, 'INVALID_SETTINGS', '城市和地图列表名称不能为空。');
  assert(!boardUrl || boardIdFromUrl(boardUrl), 'INVALID_BOARD', '请输入完整的小红书收藏夹 /board/ 链接。');
  const pollMinutes = Number(b.pollMinutes);
  assert(Number.isInteger(pollMinutes) && pollMinutes >= 5 && pollMinutes <= 1440, 'INVALID_INTERVAL', '检查间隔必须是 5–1440 分钟。');
  assert(typeof b.polling === 'boolean', 'INVALID_SETTINGS', '轮询开关无效。');
  assert(!b.polling || boardUrl, 'MISSING_BOARD', '开启自动检查前，请先选择收藏夹。');
  const old = store.getSettings();
  store.settings({ city, boardName, targetList, boardUrl, pollMinutes, polling: b.polling, lastPollAt: old.boardUrl === boardUrl ? old.lastPollAt : null });
  res.json({ ok: true });
});
app.post('/api/connections/:service/:action', (req, res) => {
  const { service, action } = req.params;
  assert(['xhs','google'].includes(service) && ['open','check'].includes(action), 'INVALID_ACTION', '连接操作无效。');
  res.status(202).json(operation(`${service} ${action}`, () => action === 'open' ? sessions.openLogin(service) : (service === 'xhs' ? xhs : google).check()));
});
app.post('/api/xhs/boards', (req, res) => res.status(202).json(operation('读取收藏夹', () => xhs.boards())));
app.post('/api/poll', (req, res) => {
  assert(req.body.extract === undefined || typeof req.body.extract === 'boolean', 'INVALID_OPTION', '识别选项必须为布尔值。');
  const detailLimit = req.body.detailLimit ?? 10;
  assert(Number.isInteger(detailLimit) && detailLimit >= 1 && detailLimit <= 10, 'INVALID_OPTION', '单次详情读取上限须为 1–10 篇。');
  res.status(202).json(operation('检查新增笔记', () => worker.pollNow({ extract: req.body.extract ?? true, detailLimit })));
});
app.post('/api/notes', (req, res) => {
  const title = text(req.body.title, 300), body = text(req.body.body, 30000), sourceUrl = text(req.body.url, 1500);
  const images = req.body.images || [];
  assert(title && (body || images.length), 'INVALID_NOTE', '请填写标题，并粘贴正文或上传截图。');
  assert(Array.isArray(images) && images.length <= 12 && images.every(i => typeof i === 'string' && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(i)), 'INVALID_IMAGES', '最多支持 12 张 PNG/JPEG/WebP 截图。');
  if (sourceUrl) { let u; try { u = new URL(sourceUrl); } catch {} assert(u?.protocol === 'https:', 'INVALID_URL', '来源链接需要是 HTTPS 地址。'); }
  const id = randomUUID(); store.addNote({ id, title, body, images, url: sourceUrl }); store.updateNote(id, { status: 'needs_extraction' });
  res.status(201).json({ id });
});
app.post('/api/notes/:id/extract', (req, res) => {
  assert(store.note(req.params.id), 'NOT_FOUND', '笔记不存在。', 404);
  res.status(202).json(operation('识别笔记地点', () => worker.extractNote(req.params.id)));
});
app.post('/api/notes/:id/places', (req, res) => {
  const place = { name: text(req.body.name), city: text(req.body.city) || store.getSettings().city, address: text(req.body.address), evidence: text(req.body.evidence, 1000) };
  assert(place.name, 'INVALID_PLACE', '请填写地点名称。');
  const ids = store.addPlaces(req.params.id, [place]); res.status(201).json({ ids });
});
app.post('/api/places/:id/search', async (req, res) => {
  const place = store.place(req.params.id); assert(place, 'NOT_FOUND', '地点不存在。', 404);
  const results = await searchPlaces(place); candidates.set(place.id, { time: Date.now(), ids: results.map(r => r.id) });
  res.json({ candidates: results.map(c => reviews.issue(place.id, { placeId: c.id, mapUrl: c.url || mapSearchUrl(`${place.name} ${place.city}`, c.id), displayedName: c.name, address: c.address })) });
});
app.post('/api/notes/:id/review', (req, res) => {
  assert(req.body.reviewed === true, 'INVALID_REVIEW', '请先完成笔记地点核对。');
  store.updateNote(req.params.id, { status: 'reviewed' });
  res.json({ ok: true });
});
app.post('/api/places/:id/sources', (req, res) => {
  const ids = req.body.noteIds;
  assert(Array.isArray(ids) && ids.length > 0 && ids.length <= 100 && ids.every(id => typeof id === 'string'), 'INVALID_SOURCES', '来源笔记无效。');
  store.linkSources(req.params.id, [...new Set(ids)]); res.json({ ok: true });
});
app.post('/api/places/:id/match', (req, res) => {
  const cached = candidates.get(req.params.id), place = store.place(req.params.id);
  assert(place && cached && Date.now() - cached.time < 600000 && cached.ids.includes(req.body.placeId), 'INVALID_CANDIDATE', '候选结果已过期，请重新搜索后选择。');
  store.match(place.id, { placeId: req.body.placeId, mapUrl: mapSearchUrl(`${place.name} ${place.city}`, req.body.placeId) });
  res.json({ ok: true });
});
app.post('/api/places/:id/browser-search', (req, res) => {
  const place = store.place(req.params.id); assert(place, 'NOT_FOUND', '地点不存在。', 404);
  res.status(202).json(operation('浏览器查找地点', () => google.openSearch(place)));
});
app.post('/api/places/:id/capture', async (req, res) => {
  assert(store.place(req.params.id), 'NOT_FOUND', '地点不存在。', 404);
  const result = await google.capture(req.body.mapUrl); store.match(req.params.id, result); res.json({ ok: true, name: result.displayedName });
});
app.get('/api/notes/:id/evidence', (req, res) => {
  const note = store.note(req.params.id); assert(note, 'NOT_FOUND', '笔记不存在。', 404);
  res.json({ id: note.id, title: note.title, body: note.body, url: note.url,
    images: note.images.map((_, i) => `/api/notes/${encodeURIComponent(note.id)}/images/${i}`) });
});
app.get('/api/notes/:id/images/:index', async (req, res) => {
  const note = store.note(req.params.id), index = Number(req.params.index);
  assert(note && Number.isInteger(index) && index >= 0 && index < note.images.length, 'NOT_FOUND', '图片不存在。', 404);
  const { type, bytes } = await evidenceImage(note.images[index]); res.type(type).send(bytes);
});
app.post('/api/places/:id/preview', async (req, res) => {
  assert(store.place(req.params.id), 'NOT_FOUND', '地点不存在。', 404);
  assert(req.body.mapUrl === undefined || typeof req.body.mapUrl === 'string', 'INVALID_URL', '地图链接无效。');
  const result = await google.capture(req.body.mapUrl || undefined);
  res.json(reviews.issue(req.params.id, result));
});
app.post('/api/places/:id/confirm', (req, res) => {
  assert(req.body.confirmed === true, 'INVALID_REVIEW', '请先核对地址和分店。');
  const result = reviews.get(req.params.id, req.body.selectionId);
  store.match(req.params.id, result); reviews.consume(req.body.selectionId);
  res.json({ ok: true });
});
app.post('/api/places/:id/defer', (req, res) => {
  assert(typeof req.body.deferred === 'boolean', 'INVALID_REVIEW', '暂存选项无效。');
  const reason = text(req.body.reason, 300);
  assert(!req.body.deferred || reason, 'INVALID_REVIEW', '请选择稍后核对的原因。');
  store.defer(req.params.id, req.body.deferred, reason); res.json({ ok: true });
});
app.post('/api/onboarding/complete', (req, res) => {
  const settings = store.getSettings();
  assert(settings.city && settings.targetList && settings.boardUrl, 'INVALID_SETTINGS', '请先完成目的地与收藏夹设置。');
  store.settings({ onboardingCompletedAt: Date.now() }); res.json({ ok: true });
});
app.post('/api/approve', (req, res) => {
  const ids = req.body.ids;
  assert(Array.isArray(ids) && ids.length > 0 && ids.length <= 50 && ids.every(id => typeof id === 'string'), 'INVALID_SELECTION', '请选择 1–50 个已确认位置的地点。');
  const jobs = store.approve([...new Set(ids)]);
  store.event('approve', `已确认 ${jobs.length} 个地点，等待保存。`);
  res.status(202).json({ jobs }); void worker.tick();
});
app.post('/api/jobs/:id/retry', (req, res) => { store.retry(req.params.id); res.json({ ok: true }); void worker.tick(); });
app.use(express.static(path.join(root, 'public')));
app.use((error, req, res, next) => {
  if (!(error instanceof AppError)) console.error(`[${new Date().toISOString()}] ${error.name}: request failed`);
  res.status(error.status || 500).json({ error: publicError(error) });
});
const server = app.listen(config.port, config.host, () => {
  fs.writeFileSync(path.join(dataDir, 'server.pid'), String(process.pid));
  console.log(`Rednote Maps: http://localhost:${config.port}`);
  console.log(JSON.stringify({ kind: 'runtime_start', time: Date.now(), pid: process.pid }));
  store.event('runtime', '后台已启动；轮询、用量记录已启用。');
  worker.start();
});
server.on('error', error => { console.error(error.code === 'EADDRINUSE' ? '端口已被占用，请打开已有服务或更改 PORT。' : '服务启动失败。'); releaseLock(); process.exit(1); });
let shuttingDown = false;
async function shutdown() {
  if (shuttingDown) return; shuttingDown = true;
  console.log(JSON.stringify({ kind: 'runtime_stop', time: Date.now(), pid: process.pid }));
  worker.stop(); server.close(); await sessions.close();
  // Allow interrupted browser operations to persist their uncertain outcome.
  const deadline = Date.now() + 5000;
  while (worker.busy && Date.now() < deadline) await new Promise(resolve => setTimeout(resolve, 100));
  if (!worker.busy && !worker.extracting.size && !Array.from(operations.values()).some(o => o.status === 'running')) store.close();
  process.exit(0);
}
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
