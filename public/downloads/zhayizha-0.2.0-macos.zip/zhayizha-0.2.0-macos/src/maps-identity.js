// Stable provider identifiers only: names and coordinates are not sufficient
// to merge two branches. Unknown URL forms retain exact-URL identity.
export function mapsIdentity(mapUrl, placeId) {
  if (placeId) return `google:${placeId}`;
  try {
    const u = new URL(mapUrl);
    if (u.protocol !== 'https:' || !['www.google.com', 'maps.google.com'].includes(u.hostname)) return `url:${mapUrl}`;
    const pid = u.searchParams.get('query_place_id');
    if (pid) return `google:${pid}`;
    const cid = u.searchParams.get('cid');
    if (/^\d+$/.test(cid || '')) return `cid:${BigInt(cid)}`;
    const entity = decodeURIComponent(u.pathname).match(/!1s0x[0-9a-f]+:(0x[0-9a-f]+)(?=!|\/|$)/i);
    if (entity) return `cid:${BigInt(entity[1])}`;
  } catch { /* Preserve exact identity for unsupported/malformed URLs. */ }
  return `url:${mapUrl}`;
}

export function mapsDetailUrl(mapUrl) {
  const identity = mapsIdentity(mapUrl);
  // Search-result detail links can retain a results pane after reload. A CID
  // addresses the exact same entity without carrying the old search context.
  return identity.startsWith('cid:') ? `https://www.google.com/maps?cid=${identity.slice(4)}&hl=en` : mapUrl;
}
