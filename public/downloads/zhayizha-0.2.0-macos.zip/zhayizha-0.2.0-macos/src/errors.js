export class AppError extends Error {
  constructor(code, message, status = 400) { super(message); this.code = code; this.status = status; }
}
export function assert(value, code, message, status) {
  if (!value) throw new AppError(code, message, status);
}
export function publicError(error) {
  if (error instanceof AppError) return { code: error.code, message: error.message };
  return { code: 'UNEXPECTED', message: '操作未完成。请重试；如持续失败，请查看本机运行日志。' };
}

// Allowlisted facts only: Playwright messages can contain signed URLs, DOM text or credentials.
export function errorDiagnostic(error) {
  const message = String(error?.message || '');
  const network = message.match(/\bnet::(ERR_[A-Z_]+)\b/)?.[1];
  const networkCode = ['ERR_INTERNET_DISCONNECTED', 'ERR_NETWORK_CHANGED', 'ERR_NAME_NOT_RESOLVED',
    'ERR_CONNECTION_RESET', 'ERR_CONNECTION_CLOSED', 'ERR_CONNECTION_REFUSED', 'ERR_CONNECTION_TIMED_OUT',
    'ERR_TIMED_OUT', 'ERR_ABORTED', 'ERR_HTTP_RESPONSE_CODE_FAILURE'].includes(network) ? network : null;
  const category = network ? 'BROWSER_NETWORK' : /page crashed/i.test(message) ? 'BROWSER_CRASHED'
    : /Target page, context or browser has been closed/i.test(message) ? 'BROWSER_CLOSED'
    : error?.name === 'TimeoutError' ? 'BROWSER_TIMEOUT' : 'UNEXPECTED';
  return { code: error instanceof AppError ? error.code : category,
    name: ['Error', 'TimeoutError', 'TypeError', 'AbortError', 'SyntaxError'].includes(error?.name) ? error.name : 'Error',
    networkCode: error?.diagnostic?.networkCode || networkCode };
}

export function browserError(error) {
  if (error instanceof AppError) return error;
  const diagnostic = errorDiagnostic(error);
  const messages = {
    BROWSER_NETWORK: '浏览器网络请求失败，请检查网络后重试。',
    BROWSER_TIMEOUT: '浏览器等待页面超时，请稍后重试。',
    BROWSER_CLOSED: '浏览器页面已关闭，请重新打开连接窗口。',
    BROWSER_CRASHED: '浏览器页面崩溃，请重新打开连接窗口。',
  };
  if (!messages[diagnostic.code]) return error;
  const wrapped = new AppError(diagnostic.code, messages[diagnostic.code]);
  wrapped.diagnostic = diagnostic;
  return wrapped;
}
