import { randomUUID } from 'node:crypto';
import { assert } from './errors.js';

// Provider names/addresses stay transient; only the chosen stable ID/URL is persisted.
export class CandidateSessions {
  entries = new Map();
  constructor({ clock = Date.now, ttl = 600000 } = {}) { this.clock = clock; this.ttl = ttl; }
  issue(placeId, candidate) {
    for (const [key, value] of this.entries) if (this.clock() - value.time >= this.ttl) this.entries.delete(key);
    while (this.entries.size >= 500) this.entries.delete(this.entries.keys().next().value);
    const selectionId = randomUUID();
    this.entries.set(selectionId, { placeId, candidate, time: this.clock() });
    return { ...candidate, selectionId };
  }
  get(placeId, selectionId) {
    const entry = this.entries.get(selectionId);
    assert(entry && entry.placeId === placeId && this.clock() - entry.time < this.ttl, 'INVALID_CANDIDATE', '候选已过期，请重新读取地图位置后确认。');
    return entry.candidate;
  }
  consume(selectionId) { this.entries.delete(selectionId); }
}
