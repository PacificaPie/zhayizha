import { normalizeImageSource } from './connectors/extraction.js';
import { assert } from './errors.js';
export async function evidenceImage(value, fetcher = fetch) {
  const source = normalizeImageSource(value), limit = 8 * 1024 * 1024;
  if (source.startsWith('data:')) {
    const [prefix, data] = source.split(',');
    assert(data.length <= Math.ceil(limit / 3) * 4, 'IMAGE_TOO_LARGE', '图片过大，请查看原笔记。');
    return { type: prefix.slice(5).split(';')[0], bytes: Buffer.from(data, 'base64') };
  }
  const response = await fetcher(source, { redirect: 'error', signal: AbortSignal.timeout(10000) });
  assert(response.ok, 'IMAGE_UNAVAILABLE', '图片暂时不可用，请查看原笔记。');
  const type = response.headers.get('content-type')?.split(';')[0];
  assert(['image/png','image/jpeg','image/webp'].includes(type), 'UNSUPPORTED_IMAGE', '图片格式不受支持。');
  const reader = response.body.getReader(), chunks = []; let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read(); if (done) break;
      total += value.length;
      assert(total <= limit, 'IMAGE_TOO_LARGE', '图片过大，请查看原笔记。');
      chunks.push(Buffer.from(value));
    }
  } finally { await reader.cancel(); }
  return { type, bytes: Buffer.concat(chunks) };
}
