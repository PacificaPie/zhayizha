import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';

export const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
export const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(root, 'data');
fs.mkdirSync(dataDir, { recursive: true, mode: 0o700 });
export const config = {
  port: Number(process.env.PORT || 4317),
  host: process.env.HOST || '127.0.0.1',
  channel: process.env.BROWSER_CHANNEL || 'chrome',
  openaiKey: process.env.OPENAI_API_KEY || '',
  openaiModel: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
  googleKey: process.env.GOOGLE_MAPS_API_KEY || '',
};
