import fs from 'node:fs';
import path from 'node:path';
import { AppError } from './errors.js';

export function acquireLock(directory) {
  const filename = path.join(directory, 'process.lock');
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const fd = fs.openSync(filename, 'wx', 0o600);
      fs.writeFileSync(fd, String(process.pid)); fs.closeSync(fd);
      return () => { try { if (fs.readFileSync(filename, 'utf8') === String(process.pid)) fs.unlinkSync(filename); } catch {} };
    } catch (error) {
      if (error.code !== 'EEXIST') throw error;
      let pid; try { pid = Number(fs.readFileSync(filename, 'utf8')); } catch {}
      let alive = false;
      if (Number.isInteger(pid) && pid > 0) { try { process.kill(pid, 0); alive = true; } catch (e) { if (e.code !== 'ESRCH') alive = true; } }
      if (alive) throw new AppError('ALREADY_RUNNING', '这个项目已在运行，请打开已有工作台，不要重复启动。');
      try { fs.unlinkSync(filename); } catch {}
    }
  }
  throw new AppError('LOCK_FAILED', '无法取得项目运行锁，请检查 data 目录权限。');
}
