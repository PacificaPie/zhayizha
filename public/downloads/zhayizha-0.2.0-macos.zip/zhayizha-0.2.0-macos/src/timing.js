// Measure active phases separately from queueing and human review time.
export function stageTimer(onTiming = () => {}, now = () => performance.now()) {
  let current;
  const end = () => {
    if (!current) return;
    const { stage, started } = current;
    current = null;
    onTiming({ stage, durationMs: Math.round(now() - started) });
  };
  return {
    start(stage) { end(); current = { stage, started: now() }; },
    end,
  };
}
