import { AppError, assert } from '../errors.js';
import { checkPage } from './browser.js';
import fs from 'node:fs/promises';
import path from 'node:path';
import { dataDir } from '../config.js';
import { stageTimer } from '../timing.js';
import { mapsDetailUrl } from '../maps-identity.js';

export function mapSearchUrl(query, placeId) {
  const u = new URL('https://www.google.com/maps/search/');
  u.searchParams.set('api', '1'); u.searchParams.set('query', query);
  if (placeId) u.searchParams.set('query_place_id', placeId);
  u.searchParams.set('hl', 'en'); return u.href;
}
export function isSpecificMapsUrl(value) {
  try {
    const u = new URL(value);
    return u.protocol === 'https:' && !u.username && !u.password && !u.port && ['www.google.com', 'maps.google.com'].includes(u.hostname)
      && (/^\/maps\/place\/[^/]+/.test(u.pathname) || (u.pathname.startsWith('/maps/search') && Boolean(u.searchParams.get('query_place_id'))) || (u.pathname.startsWith('/maps') && /^\d+$/.test(u.searchParams.get('cid') || '')));
  } catch { return false; }
}

// Unknown is deliberately distinct from unchecked: a retry must never toggle off an existing save.
export async function checkedState(locator) {
  const role = await locator.getAttribute('aria-checked');
  const pressed = await locator.getAttribute('aria-pressed');
  const value = role ?? pressed;
  if (value === 'true') return true;
  if (value === 'false') return false;
  const checkbox = locator.locator('input[type="checkbox"]');
  if (await checkbox.count() === 1) return checkbox.isChecked();
  return null;
}

function placeHeadings(page) {
  // Maps also renders a booking advertisement as an h1: "SponsoredBy Viator…".
  // Exclude that advertisement, but still require exactly one remaining title.
  return page.locator('h1').filter({ visible: true })
    .filter({ hasNotText: /^\s*(Sponsored|广告|Patrocinado)(?:\s|By|$)/i });
}

function listOptions(page) {
  return page.getByRole('menuitemcheckbox').or(page.getByRole('menuitemradio'))
    .or(page.getByRole('checkbox')).filter({ visible: true });
}

function targetListOption(page, target) {
  const exactLabel = page.getByRole('menuitemcheckbox', { name: target, exact: true })
    .or(page.getByRole('menuitemradio', { name: target, exact: true }))
    .or(page.getByRole('checkbox', { name: target, exact: true }));
  // Real Maps options append privacy and item counts to their accessible names.
  // Match the exact visible list name inside the option, never a name prefix.
  return exactLabel.or(listOptions(page).filter({ has: page.getByText(target, { exact: true }) }))
    .filter({ visible: true });
}

export class GoogleConnector {
  constructor(sessions) { this.sessions = sessions; }
  async check() {
    return this.sessions.run('google', async page => {
      await page.goto('https://www.google.com/maps?hl=en', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1500); await checkPage(page, 'google');
      this.sessions.states.google = 'connected'; return { connected: true };
    });
  }
  async openSearch(place) {
    return this.sessions.run('google', async page => {
      await page.goto(mapSearchUrl(`${place.name} ${place.address} ${place.city}`), { waitUntil: 'domcontentloaded' });
      await page.bringToFront(); return { message: '在浏览器中打开正确地点详情，然后返回点击“采用当前地点”。' };
    });
  }
  async capture(mapUrl) {
    if (mapUrl !== undefined) assert(typeof mapUrl === 'string' && isSpecificMapsUrl(mapUrl), 'INVALID_MAP_URL', '请粘贴 Google Maps 具体地点的完整链接，不支持搜索页或分享短链接。');
    return this.sessions.run('google', async page => {
      if (mapUrl !== undefined) {
        await page.goto(mapsDetailUrl(mapUrl), { waitUntil: 'domcontentloaded', timeout: 45000 });
        await page.bringToFront();
        await page.waitForTimeout(1500);
      }
      const connection = await checkPage(page, 'google', { requireLogin: false });
      const heading = placeHeadings(page);
      try { await heading.first().waitFor({ state: 'visible', timeout: 5000 }); } catch { /* explain below */ }
      const names = await heading.allTextContents();
      assert(names.length === 1, 'NOT_A_PLACE', `未识别到唯一店铺标题（当前可见标题：${names.join('、').slice(0, 300) || '无'}）。可粘贴已确认地点的完整地图链接。`);
      assert(isSpecificMapsUrl(page.url()), 'NOT_A_PLACE', '当前仍是搜索页，请点开具体地点后再采用。');
      const addressButton = page.locator('button[data-item-id="address"]').filter({ visible: true });
      const address = await addressButton.count() === 1 ? (await addressButton.innerText()).trim().slice(0, 600) : '';
      this.sessions.states.google = connection.connected ? 'connected' : 'unknown';
      return { mapUrl: page.url(), displayedName: await heading.innerText(), address };
    });
  }
  async save(job, { onTiming } = {}) {
    assert(isSpecificMapsUrl(job.map_url), 'INVALID_MAP_URL', '任务里的地图链接不是已确认的具体地点。');
    return this.sessions.run('google', async page => {
      const timer = stageTimer(onTiming);
      timer.start('open_place');
      try {
        await page.goto(mapsDetailUrl(job.map_url), { waitUntil: 'domcontentloaded', timeout: 45000 });
        await page.waitForTimeout(1500); await checkPage(page, 'google');
        // Resolve a unique detail pane before any write. No search-result guessing.
        const heading = placeHeadings(page);
        assert(await heading.count() === 1, 'NEEDS_REVIEW', '没有定位到唯一地点详情，尚未执行保存。');
        timer.start('read_list_state');
        const save = page.getByRole('button', { name: /^(Save|Saved|保存|已保存|Guardar|Guardado)(\b|$)/ }).filter({ visible: true });
        assert(await save.count() === 1, 'PAGE_CHANGED', '未找到唯一保存按钮，尚未执行保存。');
        await save.click();
        const item = targetListOption(page, job.target);
        try { await item.first().waitFor({ state: 'visible', timeout: 5000 }); } catch { /* explicit check below */ }
        if (await item.count() !== 1) {
          const available = await listOptions(page).allTextContents();
          // Keep local evidence for adapting the real UI; this never changes a list.
          if (job.id) {
            const menu = page.getByRole('menu').filter({ visible: true });
            if (await menu.count() === 1) await fs.writeFile(path.join(dataDir, 'google-save-review.txt'), await menu.ariaSnapshot(), { mode: 0o600 }).catch(() => {});
            await page.screenshot({ path: path.join(dataDir, 'google-save-review.png') }).catch(() => {});
          }
          throw new AppError('LIST_NOT_FOUND', `未找到唯一的「${job.target}」列表，未执行勾选。当前可见列表：${available.map(s => s.trim()).join('；').slice(0, 800) || '未识别到列表控件'}。`);
        }
        const before = await checkedState(item);
        assert(before !== null, 'NEEDS_REVIEW', '无法核实列表的勾选状态，已暂停以避免重复操作。');
        if (before) { this.sessions.states.google = 'connected'; return { alreadySaved: true }; }
        timer.start('write_save');
        await item.click();
        const done = page.getByRole('button', { name: /^(Done|完成|Listo)$/ }).filter({ visible: true });
        if (await done.count() === 1) await done.click();
        // Revisit the place, then inspect remote checked state; a toast/click is not proof.
        await page.waitForTimeout(1000);
        timer.start('verify_remote');
        // Maps may return a stale unchecked value immediately after saving. Revisit
        // at most three times; verification never clicks the list option again.
        for (let attempt = 0; attempt < 3; attempt++) {
          if (attempt) await page.waitForTimeout(1500);
          await page.reload({ waitUntil: 'domcontentloaded' });
          await page.waitForTimeout(1300); await checkPage(page, 'google');
          const again = page.getByRole('button', { name: /^(Save|Saved|保存|已保存|Guardar|Guardado)(\b|$)/ }).filter({ visible: true });
          assert(await again.count() === 1, 'NEEDS_REVIEW', '已尝试保存，但无法复核结果。请检查列表后重试。');
          await again.click();
          const confirmed = targetListOption(page, job.target);
          try { await confirmed.first().waitFor({ state: 'visible', timeout: 5000 }); } catch { /* fail closed */ }
          assert(await confirmed.count() === 1, 'NEEDS_REVIEW', '已尝试保存，但无法定位唯一目标列表。请检查列表后重试。');
          for (let poll = 0; poll < 9; poll++) {
            if (await checkedState(confirmed) === true) {
              this.sessions.states.google = 'connected'; return { alreadySaved: false, verificationRounds: attempt + 1 };
            }
            if (poll < 8) await page.waitForTimeout(250);
          }
        }
        throw new AppError('NEEDS_REVIEW', '已尝试保存，但远端结果尚未确认。请检查列表后重试。');
      } finally { timer.end(); }
    });
  }
}
