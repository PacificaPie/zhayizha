import { AppError, assert } from '../errors.js';
import { checkPage } from './browser.js';

export function boardIdFromUrl(value) {
  try {
    const u = new URL(value);
    if (!['www.xiaohongshu.com', 'xiaohongshu.com'].includes(u.hostname) || u.protocol !== 'https:') return null;
    return u.pathname.match(/^\/board\/([a-zA-Z0-9_-]+)\/?$/)?.[1] || null;
  } catch { return null; }
}
export function normalizeBoardNotes(raw) {
  if (!raw || !Array.isArray(raw.notes)) throw new AppError('PAGE_CHANGED', '未找到收藏夹笔记数据，请打开收藏夹检查页面。');
  return raw.notes.map(item => {
    const card = item.noteCard || item;
    const id = card.noteId || item.id || item.noteId;
    if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) return null;
    const url = new URL(`https://www.xiaohongshu.com/explore/${id}`);
    const token = item.xsecToken || card.xsecToken;
    if (token) { url.searchParams.set('xsec_token', token); url.searchParams.set('xsec_source', 'pc_user'); }
    return { id: String(id), title: card.displayTitle || card.title || '未命名笔记', url: url.href };
  }).filter(Boolean);
}
export class XhsConnector {
  constructor(sessions) { this.sessions = sessions; }
  async check() {
    return this.sessions.run('xhs', async page => {
      await page.goto('https://www.xiaohongshu.com/explore', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1200);
      await checkPage(page, 'xhs'); this.sessions.states.xhs = 'connected'; return { connected: true };
    });
  }
  async boards() {
    return this.sessions.run('xhs', async page => {
      await page.goto('https://www.xiaohongshu.com/explore', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1200); await checkPage(page, 'xhs');
      const profileId = await page.evaluate(() => {
        const unref = v => v?._value ?? v?._rawValue ?? v?.value ?? v;
        const u = unref(window.__INITIAL_STATE__?.user?.userInfo) || unref(window.__INITIAL_STATE__?.user?.user);
        if (u?.userId || u?.user_id) return u.userId || u.user_id;
        const a = Array.from(document.querySelectorAll('a[href*="/user/profile/"]')).find(a => ['我', 'Me'].includes(a.textContent.trim()));
        return a?.getAttribute('href')?.match(/\/user\/profile\/([a-zA-Z0-9_-]+)/)?.[1];
      });
      assert(profileId && /^[a-zA-Z0-9_-]+$/.test(profileId), 'PAGE_CHANGED', '无法定位你自己的主页，请重新检查登录。');
      await page.goto(`https://www.xiaohongshu.com/user/profile/${profileId}?tab=fav&subTab=board`, { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(1500); await checkPage(page, 'xhs');
      const boards = await page.evaluate(() => {
        const value = window.__INITIAL_STATE__?.board?.userBoardList;
        const raw = value?._value ?? value?._rawValue ?? value?.value ?? value;
        return Array.isArray(raw) ? raw.map(b => ({ id: String(b.id || b.boardId || ''), name: b.name || b.title || '未命名收藏夹' })) : null;
      });
      assert(boards, 'PAGE_CHANGED', '当前网页未返回收藏夹列表。可在设置中直接填写完整收藏夹链接。');
      this.sessions.states.xhs = 'connected';
      return boards.filter(b => /^[a-zA-Z0-9_-]+$/.test(b.id)).map(b => ({ ...b, url: `https://www.xiaohongshu.com/board/${b.id}` }));
    });
  }
  async notes(boardUrl, { onStage = () => {} } = {}) {
    const id = boardIdFromUrl(boardUrl); assert(id, 'INVALID_BOARD', '请先选择收藏夹或填写完整的小红书 /board/ 链接。');
    return this.sessions.run('xhs', async page => {
      onStage('board_navigation');
      await page.goto(boardUrl, { waitUntil: 'domcontentloaded', timeout: 45000 });
      onStage('board_auth');
      await page.waitForTimeout(1500); await checkPage(page, 'xhs');
      const collected = new Map(); let hasMore = false; let stagnant = 0;
      for (let i = 0; i < 20; i++) {
        onStage('board_data');
        const raw = await page.evaluate(id => {
          const unref = v => v?._value ?? v?._rawValue ?? v?.value ?? v;
          return unref(unref(window.__INITIAL_STATE__?.board?.boardFeedsMap)?.[id]) ?? null;
        }, id);
        const before = collected.size;
        for (const n of normalizeBoardNotes(raw)) collected.set(n.id, n);
        hasMore = Boolean(raw.hasMore ?? raw.has_more);
        stagnant = collected.size === before ? stagnant + 1 : 0;
        if (!hasMore || stagnant >= 2 || collected.size >= 200) break;
        onStage('board_scroll');
        await page.mouse.wheel(0, 1100); await page.waitForTimeout(1100); await checkPage(page, 'xhs');
      }
      this.sessions.states.xhs = 'connected';
      return { notes: Array.from(collected.values()), truncated: hasMore };
    });
  }
  async detail(note) {
    return this.sessions.run('xhs', async page => {
      const u = new URL(note.url);
      assert(u.protocol === 'https:' && u.hostname === 'www.xiaohongshu.com', 'INVALID_URL', '笔记链接无效。');
      await page.goto(note.url, { waitUntil: 'domcontentloaded', timeout: 45000 });
      await page.waitForTimeout(1200); await checkPage(page, 'xhs');
      const raw = await page.evaluate(id => {
        const s = window.__INITIAL_STATE__;
        const n = s?.note?.noteDetailMap?.[id]?.note || s?.noteData?.data?.noteData;
        if (!n) return null;
        return { title: n.title || '', body: n.desc || '', images: (n.imageList || []).map(i => i.urlDefault || i.urlPre || i.url || i.infoList?.[0]?.url).filter(Boolean) };
      }, note.id);
      assert(raw, 'PAGE_CHANGED', '暂时无法读取这篇笔记正文，已保留记录，可稍后重试。');
      return raw;
    });
  }
}
