import { chromium } from 'playwright';
import path from 'node:path';
import fs from 'node:fs';
import { config, dataDir } from '../config.js';
import { AppError, browserError } from '../errors.js';

export class BrowserSessions {
  contexts = new Map();
  busy = new Set();
  states = { xhs: 'unknown', google: 'unknown' };
  async context(service) {
    if (this.contexts.has(service)) return this.contexts.get(service);
    const profile = path.join(dataDir, 'profiles', service);
    fs.mkdirSync(profile, { recursive: true, mode: 0o700 });
    let context;
    try {
      context = await chromium.launchPersistentContext(profile, { channel: config.channel, headless: false, viewport: null });
    } catch {
      throw new AppError('BROWSER_START', '浏览器启动失败。请确认已安装 Chrome，且同一项目没有重复运行。');
    }
    context.setDefaultTimeout(12000);
    context.on('close', () => { this.contexts.delete(service); this.states[service] = 'unknown'; });
    this.contexts.set(service, context);
    return context;
  }
  async run(service, action) {
    if (this.busy.has(service)) throw new AppError('BROWSER_BUSY', '该浏览器正在处理任务，请稍后再试。', 409);
    this.busy.add(service);
    try {
      const context = await this.context(service);
      const page = context.pages()[0] || await context.newPage();
      return await action(page, context);
    } catch (error) {
      if (['AUTH_REQUIRED', 'VERIFICATION_REQUIRED'].includes(error.code)) this.states[service] = 'needs_login';
      if (!(error instanceof AppError)) this.states[service] = 'unknown';
      throw browserError(error);
    } finally { this.busy.delete(service); }
  }
  async openLogin(service) {
    return this.run(service, async page => {
      await page.goto(service === 'xhs' ? 'https://www.xiaohongshu.com/explore' : 'https://www.google.com/maps?hl=en', { waitUntil: 'domcontentloaded', timeout: 45000 });
      await page.bringToFront();
      this.states[service] = 'awaiting_login';
      return { message: '请在打开的独立浏览器中手动登录，完成后回到这里检查连接。' };
    });
  }
  async close() { await Promise.allSettled(Array.from(this.contexts.values(), c => c.close())); }
}

export async function checkPage(page, service, { requireLogin = true } = {}) {
  const text = (await page.locator('body').innerText()).slice(0, 18000);
  if (/\/sorry\b|captcha|verify/i.test(page.url()) || /安全验证|访问频繁|滑动验证|异常请求/.test(text)) {
    throw new AppError('VERIFICATION_REQUIRED', '平台要求验证，请在浏览器中手动完成。当前任务已暂停。');
  }
  if (service === 'xhs') {
    const loggedIn = await page.evaluate(() => {
      const state = window.__INITIAL_STATE__;
      const unref = v => v?._value ?? v?._rawValue ?? v?.value ?? v;
      const user = unref(state?.user?.userInfo) || unref(state?.user?.user);
      const self = Array.from(document.querySelectorAll('a[href*="/user/profile/"]')).some(a => ['我', 'Me'].includes(a.textContent.trim()));
      return Boolean(user?.userId || user?.user_id || self);
    });
    if (!loggedIn) throw new AppError('AUTH_REQUIRED', '尚未确认小红书登录。请登录后重试。');
  } else {
    const account = page.locator('a[href*="accounts.google.com/SignOutOptions"],button[aria-label*="Google Account"],a[aria-label*="Google Account"],a[aria-label*="Google 帐号"],a[aria-label*="Google 账号"]');
    // Public place previews may be read signed out; saves and connection checks still require login.
    if (!requireLogin && !(await account.count())) return { connected: false };
    // Maps can render the place before its account controls after a cold start.
    if (!(await account.count())) { try { await account.first().waitFor({ state: 'attached', timeout: 8000 }); } catch { /* report authentication below */ } }
    if (!(await account.count())) throw new AppError('AUTH_REQUIRED', '尚未确认 Google 登录。请在浏览器登录后重试。');
  }
  return { connected: true };
}
